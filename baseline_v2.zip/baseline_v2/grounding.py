"""Legacy heuristic verifier for offline comparison; not used by Agent.

The active reviewer is grounding_qwen.py. This module still provides shared
normalization and result helpers, and audit_grounding.py replays its old rules.
"""
from __future__ import annotations

import re
import unicodedata

from domain_rules import semantic_issues


NUMBER_WORDS = {
    "mot": 1, "moi": 1, "hai": 2, "ba": 3, "bon": 4, "tu": 4,
    "nam": 5, "lam": 5, "sau": 6, "bay": 7, "tam": 8, "chin": 9,
    "muoi": 10,
}
MONEY_UNITS = {"trieu": 1_000_000, "nghin": 1_000, "ngan": 1_000, "k": 1_000}
AMOUNT_KEYS = {"amount", "total", "price", "cost", "fare", "value"}
AMOUNT_SOURCE_FIELDS = AMOUNT_KEYS | {"result"}


def fold(value):
    text = unicodedata.normalize("NFD", str(value).casefold()).replace("đ", "d")
    text = "".join(c for c in text if not unicodedata.combining(c))
    return " ".join(text.split())


def leaves(data, path=""):
    """Yield scalar values with their JSON-like path and immediate record."""
    if isinstance(data, dict):
        for key, value in data.items():
            child = f"{path}.{key}" if path else str(key)
            if isinstance(value, (dict, list)):
                yield from leaves(value, child)
            else:
                yield child, value, data
    elif isinstance(data, list):
        for index, value in enumerate(data):
            child = f"{path}[{index}]"
            if isinstance(value, (dict, list)):
                yield from leaves(value, child)
            else:
                yield child, value, data


def equal_atom(left, right):
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return left == right
    return fold(left) == fold(right)


def request_numbers(transcript):
    """Parse common written/spoken Vietnamese amounts; no speculative math."""
    text = fold(transcript)
    found = set()
    for number, unit in re.findall(
        r"(?<!\w)(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d+)?)\s*"
        r"(trieu|nghin|ngan|k)?(?!\w)", text
    ):
        if re.fullmatch(r"\d{1,3}(?:[.,]\d{3})+", number):
            found.add(int(number.replace(".", "").replace(",", ""))
                      * MONEY_UNITS.get(unit, 1))
        else:
            found.add(int(float(number.replace(",", ".")) * MONEY_UNITS.get(unit, 1)))
    words = r"(?:mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin|muoi|tram|chuc|linh|le)"
    for phrase, unit in re.findall(
        rf"\b((?:{words}\s+){{1,5}})(trieu|nghin|ngan)\b", text
    ):
        tokens = phrase.split()
        value = 0
        if "tram" in tokens:
            index = tokens.index("tram")
            value += NUMBER_WORDS.get(tokens[index - 1], 1) * 100
            tokens = tokens[index + 1:]
        if "muoi" in tokens:
            index = tokens.index("muoi")
            value += NUMBER_WORDS.get(tokens[index - 1], 1) * 10 if index else 10
            tokens = tokens[index + 1:]
        if "chuc" in tokens:
            index = tokens.index("chuc")
            value += NUMBER_WORDS.get(tokens[index - 1], 1) * 10 if index else 10
            tokens = tokens[index + 1:]
        value += sum(NUMBER_WORDS.get(token, 0) for token in tokens)
        if value:
            found.add(value * MONEY_UNITS[unit])
    for major, minor in re.findall(
        r"\b(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\s+"
        r"trieu\s+(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\b",
        text,
    ):
        found.add(NUMBER_WORDS[major] * 1_000_000
                  + NUMBER_WORDS[minor] * 100_000)
    for major, minor in re.findall(
        rf"\b(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\s+"
        rf"trieu\s+((?:{words}\s+){{1,5}})nghin\b", text,
    ):
        parts = request_numbers(minor + "nghin")
        if parts:
            found.add(NUMBER_WORDS[major] * 1_000_000 + max(parts))
    for word in re.findall(
        r"\b(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\s+"
        r"chuc\s+trieu\b", text,
    ):
        found.add(NUMBER_WORDS[word] * 10_000_000)
    for word in re.findall(
        r"\b(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\s+"
        r"tram\s+ruoi(?:\s+nghin)?\b", text,
    ):
        found.add(NUMBER_WORDS[word] * 100_000 + 50_000)
    for word in re.findall(
        r"\b(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\s+"
        r"chuc(?:\s+nghin)?\b", text,
    ):
        found.add(NUMBER_WORDS[word] * 10_000)
    if any(word in text for word in ("chuyen", "tra", "vi", "tien")):
        for word in re.findall(
            r"\b(mot|moi|hai|ba|bon|tu|nam|lam|sau|bay|tam|chin)\s+"
            r"tram\b(?!\s*(?:do|usd|yen|jpy|eur|euro|nghin|ngan))", text,
        ):
            found.add(NUMBER_WORDS[word] * 100_000)
    return found


def _matches_request(key, value, transcript):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return value in request_numbers(transcript)
    if not isinstance(value, str):
        return False
    phrase = fold(value)
    return bool(phrase) and len(phrase) >= 3 and phrase in fold(transcript)


def _record_link(parent, args):
    """Find an argument ID that identifies the same source record, if any."""
    if not isinstance(parent, dict) or not isinstance(args, dict):
        return None
    record_ids = {value for key, value in parent.items()
                  if (key == "id" or key.endswith("_id"))
                  and isinstance(value, (str, int))}
    for key, value in args.items():
        if key.endswith("_id") and isinstance(value, (str, int)) and value in record_ids:
            return key
    return None


def _source_match(key, value, source, data, args=None):
    candidates = []
    for path, observed, parent in leaves(data):
        if not equal_atom(value, observed):
            continue
        field = path.rsplit(".", 1)[-1]
        if key in AMOUNT_KEYS:
            # A balance is not evidence for the amount to transfer.
            if field not in AMOUNT_SOURCE_FIELDS:
                continue
        match = {"source": source, "path": path}
        record_path = path.rsplit(".", 1)[0] if "." in path else ""
        if "[" in record_path:
            match["record_path"] = record_path
        linked_by = _record_link(parent, args)
        if linked_by:
            match["record_linked_by"] = linked_by
        candidates.append(match)
    return next((item for item in candidates if "record_linked_by" in item),
                candidates[0] if candidates else None)


def evidence_for(key, value, transcript, context, history, observations, args=None):
    # Current tool responses take precedence over older conversation data.
    for index in range(len(observations) - 1, -1, -1):
        item = observations[index]
        evidence = _source_match(
            key, value, f"tool_result[{index}]/{item['name']}",
            item.get("result"), args
        )
        if evidence:
            return evidence
    for source, data in (("context", context), ("history", history)):
        evidence = _source_match(key, value, source, data, args)
        if evidence:
            return evidence
        if key in AMOUNT_KEYS and isinstance(value, (int, float)):
            for path, text, _ in leaves(data):
                if isinstance(text, str) and value in request_numbers(text):
                    return {"source": source, "path": path, "derivation": "spoken_number"}
    if _matches_request(key, value, transcript):
        return {"source": "request", "path": "text"}
    return None


def lookup_hints(key, prop, specs, transcript):
    hints = []
    ref = prop.get("x-ref", "")
    if ref:
        target = ref.rsplit(".", 1)[-1].lower()
        hints.extend(
            name for name, spec in specs.items()
            if spec.get("kind") == "read"
            and target in str(spec.get("returns", "")).lower()
        )
    if key in AMOUNT_KEYS:
        # The schema does not describe cross-app joins. Suggest read tools by
        # their declared return values, without naming an app or bill type.
        monetary_terms = ("bill", "invoice", "price", "cost", "fare", "amount")
        hints.extend(
            name for name, spec in specs.items()
            if spec.get("kind") == "read"
            and any(term in str(spec.get("returns", "")).lower()
                    for term in monetary_terms)
        )
    return sorted(set(hints))


def derived_amount_context(transcript, history, observations):
    """Return a possible arithmetic source, or None.

    This is a soft pass: the source is visible but the arithmetic is not fully
    proved. The caller records the field as unverified for later inspection.
    """
    request = fold(transcript)
    if not any(cue in request for cue in (
        "so do", "so day", "khoan do", "khoan day", "moi", "nua",
        "bao nhieu", "theo gia", "gia", "lit", "chi ", "tieng",
        "ve", "hoc phi", "thue", "tong", "phan", "tron",
    )):
        return None
    for index, item in enumerate(observations):
        result = item.get("result")
        for path, value, _ in leaves(result):
            field = path.rsplit(".", 1)[-1]
            if isinstance(value, (int, float)) and field in (
                "price", "price_per_hour", "price_per_liter", "rate",
                "sell", "buy", "cost", "fare",
            ):
                return {"source": f"tool_result[{index}]/{item['name']}",
                        "path": path, "derivation": "arithmetic_unverified"}
    for index, turn in enumerate(history):
        for path, value, _ in leaves(turn):
            if isinstance(value, str):
                normalized = fold(value)
                if request_numbers(value) and any(
                    cue in normalized for cue in (
                        "gia", "ve", "hoc phi", "tong cong", "tien", "chuyen",
                        "khoan", "tra", "nghin", "trieu",
                    )
                ):
                    return {"source": f"history[{index}]",
                            "path": path, "derivation": "arithmetic_unverified"}
    return None


def verify_call(name, args, spec, transcript, context, history, observations, specs):
    """Return evidence and errors. Never infer correctness from a scalar alone."""
    props = (spec.get("parameters") or {}).get("properties") or {}
    evidence = {}
    issues = []
    unverified = []
    is_write = spec.get("kind") == "write"
    for key, value in args.items():
        prop = props.get(key, {})
        found = evidence_for(key, value, transcript, context, history,
                             observations, args)
        if found:
            evidence[key] = found
            continue
        critical = key.endswith("_id") or (is_write and key in AMOUNT_KEYS)
        if is_write and key in AMOUNT_KEYS and isinstance(value, (int, float)):
            derived = derived_amount_context(transcript, history, observations)
            if derived:
                evidence[key] = derived
                unverified.append(key)
                continue
        if critical:
            hints = lookup_hints(key, prop, specs, transcript)
            issues.append({
                "code": "ungrounded_argument", "field": key, "value": value,
                "message": f"{key} chưa có căn cứ từ request/context/history/tool result.",
                "lookup_tools": hints,
            })
        else:
            unverified.append(key)
    # If an ID and amount come from the same observed collection, they must
    # refer to the same record. Proposed new state fields (such as a new
    # calendar start time) need not equal the old record's fields.
    sourced = [(key, item) for key, item in evidence.items()
               if item.get("record_path")
               and (key.endswith("_id") or key in AMOUNT_KEYS)]
    for left_index, (left_key, left) in enumerate(sourced):
        for right_key, right in sourced[left_index + 1:]:
            if (left["source"] != right["source"]
                    or not left["source"].startswith("tool_result[")):
                continue
            left_match = re.fullmatch(r"(.*)\[\d+\]", left["record_path"])
            right_match = re.fullmatch(r"(.*)\[\d+\]", right["record_path"])
            if not left_match or not right_match:
                continue
            left_collection, right_collection = left_match[1], right_match[1]
            if (not (left_key in AMOUNT_KEYS or right_key in AMOUNT_KEYS)):
                continue
            if (left_collection == right_collection
                    and left["record_path"] != right["record_path"]):
                issues.append({
                    "code": "cross_record_argument", "field": right_key,
                    "message": (
                        f"{left_key} và {right_key} đến từ hai bản ghi khác nhau "
                        f"trong {left_collection}."
                    ),
                    "lookup_tools": [],
                })
    issues.extend(semantic_issues(name, args, transcript, observations, fold))
    return {
        "ok": not issues, "issues": issues,
        "evidence": evidence, "unverified_fields": unverified,
    }


def result_succeeded(result):
    return isinstance(result, dict) and result.get("ok") is not False and result.get("done") is not False


def result_facts(result):
    if not isinstance(result, (dict, list)):
        return set()
    return {(path, str(value)) for path, value, _ in leaves(result)}
