"""Offline audit of the retired heuristic verifier, not Qwen grounding.

This script is never imported by the agent or submission runner.
"""
from __future__ import annotations

import argparse
from collections import Counter

from common import allowed_specs, compact_history, find_root, import_toolenv, load_catalog, load_train
from grounding import verify_call


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", default=None)
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    root = find_root(args.data_root)
    rows = load_train(root, args.limit, args.seed)
    catalog = load_catalog(root)
    ToolEnv = import_toolenv(root)
    issues = Counter()
    examples = []
    total = 0
    rejected = 0
    for row in rows:
        env = ToolEnv("train", row["id"], root=root)
        specs = {spec["name"]: spec for spec in allowed_specs(row, catalog)}
        observations = []
        context = {key: value for key, value in row["context"].items()
                   if key != "installed_apps"}
        history = compact_history(row.get("history") or [])
        for call in row["label"]["tool_calls"]:
            name, arguments = call["name"], call.get("arguments") or {}
            total += 1
            check = verify_call(
                name, arguments, specs[name], row["audio_text"],
                context, history, observations, specs
            )
            if not check["ok"]:
                rejected += 1
                issues.update(item["code"] for item in check["issues"])
                if len(examples) < 20:
                    examples.append((row["id"], name, arguments, check["issues"]))
            result = env.call(name, arguments)
            observations.append({
                "name": name, "arguments": arguments, "result": result,
            })
    print(f"Gold calls: {total}; verifier rejections: {rejected} ({rejected / total:.1%})")
    print("Issue codes:", dict(issues))
    for sample_id, name, arguments, errors in examples:
        print(sample_id, name, arguments, errors)


if __name__ == "__main__":
    main()
