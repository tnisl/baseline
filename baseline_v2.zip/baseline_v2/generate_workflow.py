"""Render the implemented baseline_v2 flow as SVG and PNG."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon


ROOT = Path(__file__).resolve().parent
FIG, AX = plt.subplots(figsize=(19, 23))
FIG.patch.set_facecolor("#f7f9fc")
AX.set_facecolor("#f7f9fc")
AX.set_xlim(0, 2600)
AX.set_ylim(2850, 0)
AX.axis("off")

BLUE = ("#e4f2ff", "#4779a7")
PURPLE = ("#ece5ff", "#7858af")
YELLOW = ("#fff1c6", "#a77d32")
GREEN = ("#ddf5e3", "#42875b")
CORAL = ("#ffe7df", "#b76552")
INK = "#183149"
LINE = "#53677b"


def box(cx, cy, width, height, title, detail="", color=BLUE, size=16):
    x, y = cx - width / 2, cy - height / 2
    AX.add_patch(FancyBboxPatch(
        (x, y), width, height, boxstyle="round,pad=0.02,rounding_size=22",
        facecolor=color[0], edgecolor=color[1], linewidth=2.2,
    ))
    if detail:
        AX.text(cx, y + 29, title, ha="center", va="center",
                fontsize=size, fontweight="bold", color=INK)
        AX.text(cx, y + 55, detail, ha="center", va="top",
                fontsize=11.8, color="#40566a", linespacing=1.25)
    else:
        AX.text(cx, cy, title, ha="center", va="center",
                fontsize=size, fontweight="bold", color=INK)


def diamond(cx, cy, width, height, title, detail=""):
    AX.add_patch(Polygon(
        [(cx, cy - height / 2), (cx + width / 2, cy),
         (cx, cy + height / 2), (cx - width / 2, cy)],
        closed=True, facecolor=YELLOW[0], edgecolor=YELLOW[1], linewidth=2.2,
    ))
    AX.text(cx, cy - (11 if detail else 0), title, ha="center", va="center",
            fontsize=15, fontweight="bold", color=INK)
    if detail:
        AX.text(cx, cy + 20, detail, ha="center", va="center",
                fontsize=11.2, color="#40566a")


def arrow(points, label=None, color=LINE, dotted=False, label_at=None):
    style = (0, (6, 5)) if dotted else "solid"
    for a, b in zip(points[:-2], points[1:-1]):
        AX.plot((a[0], b[0]), (a[1], b[1]), color=color,
                linewidth=2.1, linestyle=style, solid_capstyle="round")
    AX.add_patch(FancyArrowPatch(
        points[-2], points[-1], arrowstyle="-|>", mutation_scale=18,
        linewidth=2.1, linestyle=style, color=color,
    ))
    if label:
        x, y = label_at or ((points[0][0] + points[-1][0]) / 2,
                             (points[0][1] + points[-1][1]) / 2)
        AX.text(x, y, label, ha="center", va="center", fontsize=11.5,
                fontweight="bold", color=color,
                bbox=dict(facecolor="#f7f9fc", edgecolor="none", pad=2))


AX.text(1300, 65, "LifeMate baseline_v2 · Workflow thực thi",
        ha="center", fontsize=27, fontweight="bold", color=INK)
AX.text(1300, 108, "Qwen planner có mẫu JSON định dạng · 5 reviewer dùng prompt riêng, không có ví dụ",
        ha="center", fontsize=13.5, color="#50657a")

# Input pipeline. Workflow-only takes the gold transcript at the input boundary.
box(210, 235, 270, 93, "Speech", "audio của mẫu", BLUE)
box(690, 235, 430, 93, "PhoWhisper-medium", "ASR → transcript", BLUE)
box(1290, 235, 620, 108, "Input cho agent", "request · context · history · available_tools", BLUE)
box(2110, 235, 580, 93, "Workflow only", "dùng transcript chuẩn thay cho ASR", BLUE)
arrow([(345, 235), (475, 235)])
arrow([(905, 235), (980, 235)])
arrow([(1820, 235), (1610, 235)], dotted=True)

box(1200, 415, 640, 105, "Qwen planner", "chọn một action; call kèm arguments + sources", PURPLE)
arrow([(1290, 289), (1290, 335), (1200, 335), (1200, 363)])
diamond(1200, 585, 330, 116, "Action?", "call / ask / done")
arrow([(1200, 468), (1200, 527)])

box(2130, 585, 560, 105, "RETURN", "tool_calls · state_hash", GREEN)
arrow([(1365, 585), (1850, 585)], "done", label_at=(1640, 562))

box(365, 790, 590, 280, "Nhánh ask", "Code: valid_ask → Qwen: missing_params\nHợp lệ: sys.ask_missing_info → RETURN\nRead tool gọi được với {}: đổi thành call {}\nBác bỏ: feedback → planner", PURPLE, size=17)
arrow([(1035, 585), (765, 585), (765, 790), (660, 790)],
      "ask", label_at=(748, 630))

box(1200, 770, 640, 92, "Code: action và tool hợp lệ?", "JSON đúng dạng · tool nằm trong available_tools", YELLOW)
arrow([(1200, 643), (1200, 724)], "call", label_at=(1240, 687))

diamond(1200, 935, 440, 120, "Thiếu required", "hoặc x-one-of?")
arrow([(1200, 816), (1200, 875)])
box(375, 1080, 620, 140, "Qwen: missing_params", "Lý do vào feedback; chỉ ask nếu không thể tra\nvà đã hết lượt sửa", PURPLE)
arrow([(980, 935), (720, 935), (720, 1080), (685, 1080)],
      "có", label_at=(810, 914))

diamond(1200, 1115, 440, 115, "arguments = {}", "và schema cho phép?")
arrow([(1200, 995), (1200, 1057)], "không", label_at=(1255, 1028))

box(1200, 1290, 640, 92, "Qwen: schema review", "required · type · enum · format · trường hợp lệ", PURPLE)
arrow([(1200, 1173), (1200, 1244)], "không", label_at=(1255, 1210))
box(1200, 1445, 640, 92, "Code: env.validate()", "kiểm tra schema của ToolEnv", YELLOW)
arrow([(1200, 1336), (1200, 1399)])
box(1200, 1600, 640, 92, "Code: kiểm tra sources planner", "đủ key · path/quote có thật · giá trị khớp", YELLOW)
arrow([(1200, 1491), (1200, 1554)])
box(1200, 1755, 640, 92, "Qwen: argument_sources", "trả nguồn độc lập; code xác minh lần nữa", PURPLE)
arrow([(1200, 1646), (1200, 1709)])
box(1200, 1910, 640, 92, "Qwen: relevance", "tool có ích cho bước tiếp theo?", PURPLE)
arrow([(1200, 1801), (1200, 1864)])

# Zero-argument read calls bypass schema, sources and semantic argument review.
arrow([(980, 1115), (810, 1115), (810, 1910), (880, 1910)],
      "có: bỏ qua schema + sources", label_at=(760, 1240))

box(1200, 2065, 640, 92, "Qwen: arguments", "giá trị có đúng đối tượng, bản ghi, điều kiện?", PURPLE)
arrow([(1200, 1956), (1200, 2019)], "có arguments", label_at=(1280, 1985))

diamond(1200, 2240, 440, 120, "Call đã chạy?", "chặn trùng name + arguments")
arrow([(1200, 2111), (1200, 2180)])
arrow([(880, 1910), (760, 1910), (760, 2240), (980, 2240)],
      "arguments={}: bỏ qua review giá trị", label_at=(760, 2025))

box(1200, 2415, 640, 95, "env.call(name, arguments)", "lưu tool call và nhận tool result", GREEN)
arrow([(1200, 2300), (1200, 2368)], "chưa", label_at=(1245, 2335))
box(1200, 2580, 740, 120, "Tool result → context", "kiểm tra ok/done và dữ liệu mới; Qwen quyết định tiếp", BLUE)
arrow([(1200, 2463), (1200, 2520)])

# Rejection path is a shared bus; the full reason is returned to the planner.
box(2175, 1620, 660, 250, "Feedback cho planner", "Lý do từ Qwen/code → sửa action hoặc nguồn\nLặp cùng lỗi, hết lượt sửa hoặc không tiến triển:\nRETURN với các tool_calls đã thực thi", CORAL)
for y in (770, 1290, 1445, 1600, 1755, 1910, 2065, 2240):
    AX.plot((1520 if y != 2240 else 1420, 1815), (y, y),
            color=CORAL[1], linewidth=1.7)
AX.plot((1815, 1815), (770, 2240), color=CORAL[1], linewidth=1.8)
arrow([(1815, 1620), (1845, 1620)], color=CORAL[1])
AX.text(1740, 752, "bác bỏ / sai / trùng", ha="right", fontsize=11.5,
        color=CORAL[1], fontweight="bold")
arrow([(2175, 1495), (2480, 1495), (2480, 410), (1520, 410)],
      "nếu còn lượt", color=CORAL[1], label_at=(2470, 1220))

# Tool result and missing-parameter feedback re-enter the same planner loop.
arrow([(830, 2580), (45, 2580), (45, 415), (880, 415)],
      "tool result / không có thông tin mới", label_at=(355, 2550))
arrow([(375, 1150), (375, 1190), (65, 1190), (65, 415), (880, 415)],
      color=CORAL[1], dotted=True)

AX.text(1300, 2775,
        "Giới hạn trong code: 10 tool calls · 24 decisions · 3 repairs · 2 lần không tiến triển",
        ha="center", fontsize=13, fontweight="bold", color="#40566a")

FIG.subplots_adjust(left=0.02, right=0.98, top=0.99, bottom=0.01)
FIG.savefig(ROOT / "workflow.svg", facecolor=FIG.get_facecolor())
FIG.savefig(ROOT / "workflow.png", dpi=150, facecolor=FIG.get_facecolor())
plt.close(FIG)
