"""One citation format shared by the planner, source reviewer, and verifier."""

SOURCE_ORIGINS = frozenset({
    "input", "context", "history", "previous_tool_calls", "derived", "schema",
})

SOURCE_FORMAT = """ĐỊNH DẠNG NGUỒN CHUNG (thay mọi <placeholder> bằng dữ liệu thật trước khi xuất JSON):
1. `sources` là object ở cấp action/review. Mỗi key phải GIỐNG HỆT tên một key trong `arguments`, kể cả argument tùy chọn. `set(sources) == set(arguments)`. Mỗi giá trị của `sources` là MỘT object nguồn có `origin`, không phải chuỗi. Nếu `arguments={}` thì `sources={}`; không tự thêm key. Reviewer chấp nhận thì trả object chỉ có key `sources`; planner đặt `sources` cạnh `arguments` trong action.
2. Chỉ dùng sáu giá trị origin và đúng các trường tương ứng dưới đây; không thêm/bớt trường, không đổi tên `origin` thành `source`:
   input: {"origin":"input","quote":"<đoạn nguyên văn trong request>"}
   context: {"origin":"context","path":"<đường dẫn từ context>"}
   history: {"origin":"history","path":"<đường dẫn từ history>"}
   previous_tool_calls: {"origin":"previous_tool_calls","index":<số nguyên từ 0>,"part":"result","path":"<đường dẫn trong result>"} hoặc cùng cấu trúc với `part` là "arguments" và path trong arguments.
   derived: {"origin":"derived","inputs":[<một hoặc nhiều object nguồn đúng định dạng ở đây>],"rule":"<quy tắc suy ra giá trị argument từ inputs>"}
   schema: {"origin":"schema","path":"<đường dẫn từ tool spec tới trường .default>"}
3. `input` chỉ dùng khi quote thực sự xuất hiện trong request VÀ giá trị argument là chuỗi có trong quote hoặc số có trong quote. Không dùng input trực tiếp cho giá trị cần dịch, chuẩn hóa, suy ngày giờ, đổi kiểu hoặc tính toán. Khi đó dùng `derived`, đặt quote nguyên văn vào `inputs`, và ghi `rule` giải thích chính xác phép biến đổi. Enum tiếng Anh suy từ từ tiếng Việt trong request cũng phải dùng `derived`.
4. `context`, `history`, `previous_tool_calls` phải có path tồn tại, trỏ tới giá trị cụ thể khớp argument; không trỏ tới cả object/list. Path dùng dấu chấm cho key và `[i]` cho phần tử list, i bắt đầu từ 0. `history` bắt đầu từ list history; `context` bắt đầu từ object context. Với `previous_tool_calls`, index là thứ tự trong `tool_observations` của lượt hiện tại, `part` chọn `result` hoặc `arguments`, rồi path bắt đầu từ object của part đó; không ghi lại `result.` hoặc `arguments.` ở đầu path.
5. `schema` chỉ dùng khi tool spec thực sự khai báo default và path kết thúc bằng `.default`; giá trị default phải khớp argument. Không dùng enum hay mô tả schema làm nguồn cho giá trị chưa có.
6. Không dùng alias `request`, `tool_result`, `tool_call`. Nguồn `derived` xác minh được các input có thật; quy tắc suy ra còn cần Qwen review ý nghĩa.
"""
