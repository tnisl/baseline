"""Small, explicit Qwen reviews for each decision node in the workflow.

Each reviewer may reject with one short reason. The source reviewer additionally
returns a provenance object for every argument; code verifies those citations.
"""
from __future__ import annotations

import json

from common import dumps
from source_contract import SOURCE_FORMAT


MISSING_SYSTEM = """Bạn review node THIẾU THAM SỐ của tool.
Xét action được đề xuất và schema tool. Nếu là call, mọi required/x-one-of phải có giá trị; nếu thiếu, bác bỏ và nêu đúng trường thiếu. Nếu là ask, chỉ chấp nhận khi trường hỏi là required/x-one-of và không thể lấy bằng read/search tool, request, context, history hay tool result. Đừng bắt read tool có arguments={} đi hỏi người dùng.
Chỉ trả JSON {} nếu hợp lệ; nếu bác bỏ, chỉ trả {"reject_reason":"lý do cụ thể, tối đa 20 từ"}. Không thêm trường khác.
"""

RELEVANCE_SYSTEM = """Bạn review node TOOL PHÙ HỢP: call này có hữu ích làm bước tiếp theo cho request không?
Read/search được chấp nhận nếu giúp tra thông tin cần cho bước sau, dù chưa hoàn thành yêu cầu. Chỉ bác bỏ tool khi không có quan hệ hợp lý với thông tin hoặc hành động đang cần. Write phải đúng mục tiêu và điều kiện đã biết. Chỉ xét độ phù hợp của tool; schema và nguồn đã được kiểm tra ở các node trước, còn ý nghĩa từng giá trị argument sẽ xét ở node sau.
Chỉ trả JSON {} nếu phù hợp; nếu bác bỏ, chỉ trả {"reject_reason":"lý do cụ thể, tối đa 20 từ"}. Không thêm trường khác.
"""

SOURCE_SYSTEM = """Bạn review node NGUỒN ARGUMENT sau khi schema đã hợp lệ. Với MỖI argument, tự xác nhận giá trị có căn cứ trong dữ liệu hiển thị và trả nguồn gốc cụ thể. Không chấp nhận một nguồn chỉ vì planner đã khai báo nó.
Khi chấp nhận, chỉ trả object có key `sources`; trong đó mỗi argument có một object chứa `origin`. Key trong `sources` phải khớp CHÍNH XÁC với action.arguments. Không trả key `origin` ở cấp ngoài thay cho `sources`. Khi bác bỏ, chỉ trả {"reject_reason":"lý do cụ thể, tối đa 20 từ"}. Không thêm trường khác.
""" + "\n" + SOURCE_FORMAT

ARGUMENT_SYSTEM = """Bạn review node GIÁ TRỊ ARGUMENT sau khi nguồn đã được kiểm tra. Xét ý nghĩa của từng giá trị trong request và kết quả tool: có đúng đối tượng, đúng bản ghi, đúng điều kiện và đúng hành động không? Nguồn tồn tại chưa đủ để chứng minh chọn đúng. Read/search query gần đúng tên người hoặc chủ đề có thể hữu ích; đừng đòi read tool hoàn thành mục tiêu cuối.
Chỉ trả JSON {} nếu hợp lệ; nếu bác bỏ, chỉ trả {"reject_reason":"lý do cụ thể, tối đa 20 từ"}. Không thêm trường khác.
"""

SCHEMA_SYSTEM = """Bạn review node SCHEMA ARGUMENT. Chỉ xét arguments theo schema của tool: required, x-one-of, type, enum, format và trường không được phép. Không xét ý nghĩa nghiệp vụ hoặc nguồn. Code sẽ gọi env.validate() sau review này.
Chỉ trả JSON {} nếu hợp lệ; nếu bác bỏ, chỉ trả {"reject_reason":"lý do cụ thể, tối đa 20 từ"}. Không thêm trường khác.
"""

SYSTEMS = {
    "missing_params": MISSING_SYSTEM,
    "relevance": RELEVANCE_SYSTEM,
    "argument_sources": SOURCE_SYSTEM,
    "arguments": ARGUMENT_SYSTEM,
    "schema": SCHEMA_SYSTEM,
}


def _first_json(text):
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            return value
    return None


def _short_reason(value):
    if not isinstance(value, str) or not value.strip():
        return None
    return " ".join(value.split()[:20])[:180]


def review_node(llm, node, payload, max_prompt_tokens, max_new_tokens):
    """Run one Qwen node. Source approval uses the shared sources contract."""
    if node not in SYSTEMS:
        raise ValueError(f"Unknown review node: {node}")
    data = dict(payload)
    data["history"] = list(data.get("history") or [])
    data["tool_observations"] = list(data.get("tool_observations") or [])
    budget = min(max_new_tokens, 256 if node == "argument_sources" else 96)
    while True:
        messages = [
            {"role": "system", "content": SYSTEMS[node]},
            {"role": "user", "content": dumps(data)},
        ]
        if llm.count(messages) + budget <= max_prompt_tokens:
            break
        if data["history"]:
            data["history"].pop(0)
        elif data["tool_observations"]:
            data["tool_observations"].pop(0)
        else:
            return {"ok": False, "reason": "Review vượt giới hạn context.",
                    "review": None, "sources": None,
                    "usage": {"prompt_tokens": 0, "generation_tokens": 0,
                              "latency_s": 0.0}}
    output = llm.complete(messages, max_new_tokens=budget)
    usage = {key: output[key] for key in
             ("prompt_tokens", "generation_tokens", "latency_s")}
    verdict = _first_json(output["text"])
    if verdict is None:
        reason = "Review không trả JSON object hợp lệ."
    elif node == "argument_sources":
        extra = set(verdict) - {"sources", "reject_reason"}
        reason = _short_reason(verdict.get("reject_reason"))
        sources = verdict.get("sources")
        arguments = (data.get("action") or {}).get("arguments") or {}
        if extra or ("reject_reason" in verdict and reason is None):
            reason = "Review nguồn trả sai cấu trúc."
        elif reason is None and (not isinstance(sources, dict)
                                 or set(sources) != set(arguments)):
            expected = ", ".join(sorted(arguments))
            received = ", ".join(sorted(sources)) if isinstance(sources, dict) else "không có"
            reason = f"sources cần đúng key [{expected}]; đã nhận [{received}]."
    else:
        reason = _short_reason(verdict.get("reject_reason"))
        if set(verdict) - {"reject_reason"} or ("reject_reason" in verdict and reason is None):
            reason = "Review trả sai cấu trúc."
    return {"ok": reason is None, "reason": reason, "review": verdict,
            "sources": verdict.get("sources") if isinstance(verdict, dict) else None,
            "usage": usage}
