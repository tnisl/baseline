"""Deterministic verification of planner and Qwen-reviewer source citations."""
from __future__ import annotations

import re

from grounding import equal_atom, fold, request_numbers
from source_contract import SOURCE_ORIGINS


def _path_parts(path):
    if not isinstance(path, str) or not path:
        raise ValueError("source path phải là chuỗi không rỗng")
    parts = []
    position = 0
    for match in re.finditer(r"(?:^|\.)([A-Za-z_][A-Za-z0-9_-]*)|\[(\d+)\]", path):
        if match.start() != position:
            raise ValueError(f"source path không hợp lệ: {path}")
        parts.append(int(match[2]) if match[2] is not None else match[1])
        position = match.end()
    if position != len(path):
        raise ValueError(f"source path không hợp lệ: {path}")
    return parts


def _read_path(data, path):
    parts = _path_parts(path)
    value = data
    for part in parts:
        if isinstance(part, int) and isinstance(value, list) and 0 <= part < len(value):
            value = value[part]
        elif isinstance(part, str) and isinstance(value, dict) and part in value:
            value = value[part]
        else:
            raise ValueError(f"source path không tồn tại: {path}")
    return value


def _validate_source(source):
    """Require the shared citation format, including inside derived inputs."""
    if not isinstance(source, dict):
        raise ValueError("source phải là object có origin")
    origin = source.get("origin")
    if origin not in SOURCE_ORIGINS:
        raise ValueError(f"origin không hợp lệ: {origin!r}; dùng định dạng nguồn chung")
    allowed = {
        "input": {"origin", "quote"},
        "context": {"origin", "path"},
        "history": {"origin", "path"},
        "previous_tool_calls": {"origin", "index", "part", "path"},
        "derived": {"origin", "inputs", "rule"},
        "schema": {"origin", "path"},
    }[origin]
    if set(source) != allowed:
        raise ValueError(f"source {origin} cần đúng các trường {sorted(allowed)}")
    if origin == "previous_tool_calls" and source["part"] not in ("result", "arguments"):
        raise ValueError("previous_tool_calls cần part=result hoặc arguments")
    if origin == "derived":
        inputs = source["inputs"]
        if not isinstance(inputs, list) or not inputs:
            raise ValueError("derived cần inputs không rỗng")
        for item in inputs:
            _validate_source(item)
    return source


def _source_value(source, transcript, context, history, observations, spec):
    source = _validate_source(source)
    origin = source.get("origin")
    if origin == "derived":
        inputs = source.get("inputs")
        rule = source.get("rule")
        if not isinstance(inputs, list) or not inputs or not isinstance(rule, str) or not rule.strip():
            raise ValueError("derived cần inputs và rule")
        return {"inputs": [
            _source_value(item, transcript, context, history, observations, spec)
            for item in inputs
        ], "rule": rule}
    if origin == "input":
        quote = source.get("quote")
        if not isinstance(quote, str) or not quote.strip() or fold(quote) not in fold(transcript):
            raise ValueError("quote không xuất hiện trong request")
        return quote
    if origin in ("context", "history", "schema"):
        root = {"context": context, "history": history, "schema": spec}[origin]
        return _read_path(root, source.get("path"))
    if origin == "previous_tool_calls":
        index = source.get("index")
        if not isinstance(index, int) or isinstance(index, bool) or not 0 <= index < len(observations):
            raise ValueError("tool index không tồn tại")
        root = observations[index][source["part"]]
        return _read_path(root, source.get("path"))
    raise ValueError(f"origin không hợp lệ: {origin!r}")


def _citation_issue(key, value, source, transcript, context, history,
                    observations, spec):
    try:
        source = _validate_source(source)
        observed = _source_value(source, transcript, context, history,
                                 observations, spec)
    except ValueError as error:
        return {"code": "invalid_source", "field": key, "message": str(error)}, None
    if source["origin"] == "derived":
        return None, observed
    if source["origin"] == "schema":
        if ".default" not in source.get("path", "") or not equal_atom(value, observed):
            return {"code": "invalid_default", "field": key,
                    "message": "schema chỉ là nguồn cho giá trị default được khai báo."}, observed
        return None, observed
    if source["origin"] == "input":
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if value not in request_numbers(observed):
                return {"code": "source_value_mismatch", "field": key,
                        "message": "Số đề xuất không xuất hiện trong đoạn request được dẫn; dùng derived nếu cần tính."}, observed
        elif isinstance(value, str):
            if not fold(value) or fold(value) not in fold(observed):
                return {"code": "source_value_mismatch", "field": key,
                        "message": "Chuỗi argument không xuất hiện trong quote; dùng derived nếu cần chuẩn hóa hay dịch ý."}, observed
        else:
            return {"code": "source_value_mismatch", "field": key,
                    "message": "Giá trị không phải số/chuỗi nguyên văn; dùng derived và nêu quy tắc suy ra."}, observed
        return None, observed
    if isinstance(observed, (dict, list)):
        return {"code": "source_not_scalar", "field": key,
                "message": "Nguồn phải trỏ đến giá trị cụ thể, không phải toàn bộ bản ghi."}, observed
    if not equal_atom(value, observed):
        return {"code": "source_value_mismatch", "field": key,
                "message": "Giá trị argument khác giá trị tại source path."}, observed
    return None, observed


def check_sources(action, spec, transcript, context, history, observations):
    """Check one citation per argument after relevance has been approved."""
    args = action["arguments"]
    sources = action.get("sources")
    issues = []
    evidence = {}
    unverified = []
    if args and (not isinstance(sources, dict) or set(sources) != set(args)):
        source_keys = set(sources) if isinstance(sources, dict) else set()
        missing = sorted(set(args) - source_keys)
        extra = sorted(source_keys - set(args))
        details = []
        if missing:
            details.append("thiếu: " + ", ".join(missing))
        if extra:
            details.append("thừa: " + ", ".join(extra))
        issues.append({"code": "missing_argument_sources", "field": None,
                       "message": "sources phải khớp arguments"
                                  + ("; " + "; ".join(details) if details else "") + "."})
    elif args:
        for key, value in args.items():
            issue, observed = _citation_issue(
                key, value, sources[key], transcript, context, history,
                observations, spec
            )
            if issue:
                issues.append(issue)
            else:
                evidence[key] = {"source": sources[key], "observed": observed}
                if sources[key].get("origin") == "derived":
                    unverified.append(key)
    return {"ok": not issues, "issues": issues, "evidence": evidence,
            "unverified_fields": unverified}


