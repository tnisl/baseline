"""LifeMate v2 agent: schema, evidence and tool-result checks in one ToolEnv."""
from __future__ import annotations

import json
import time
from collections import Counter

from common import allowed_specs, compact_history, dumps
from grounding import result_facts, result_succeeded
from grounding_qwen import check_sources
from node_reviews import review_node
from source_contract import SOURCE_FORMAT


SYSTEM = """Bạn là agent hiểu ngữ cảnh, xử lý yêu cầu nói tiếng Việt bằng các tool có sẵn.
Mỗi lượt chỉ xuất MỘT object JSON, không markdown, không giải thích. Action type là `call`, `ask` hoặc `done`.
Với `call`, cung cấp `name` (tên tool), `arguments` (object) và `sources` (object).
Với `ask`, cung cấp `tool_name` (tên tool đích) và `params` (danh sách tên tham số bắt buộc cần hỏi).
Với `done`, không cần trường bổ sung.
Các mẫu JSON chỉ minh họa định dạng; thay mọi tên tool, tên trường, giá trị và nguồn theo input thực tế:
{"type":"call","name":"<available_tool_name>","arguments":{},"sources":{}}
{"type":"call","name":"<available_tool_name>","arguments":{"<field_a>":"<value_a>","<field_b>":"<value_b>"},"sources":{"<field_a>":{"origin":"input","quote":"<exact_request_text>"},"<field_b>":{"origin":"previous_tool_calls","index":0,"part":"result","path":"<path_to_value_b>"}}}
{"type":"ask","tool_name":"<target_tool_name>","params":["<required_field_name>"]}
{"type":"done"}
Không xuất placeholder; sources phải có đúng một mục cho từng key trong arguments thực tế.

Quy tắc:
- Chỉ chọn tool trong available_tools. Mỗi lượt xuất đúng MỘT action JSON; không viết chuỗi nhiều JSON cho các bước tiếp theo. Sau call sẽ nhận tool response rồi mới quyết định tiếp.
- Nếu không rõ việc cần làm, ngoài phạm vi tool, điều kiện không thỏa, hoặc đã hoàn thành: done.
- Với dữ liệu có thể tra cứu (ID, số tiền hóa đơn, số dư, lịch, liên hệ...), gọi read/search tool trước. Không tự tạo giá trị.
- Trước khi xuất call, đọc `parameters.properties` và `required`/`x-one-of` của ĐÚNG tool. Chọn `arguments` theo schema, kể cả trường tùy chọn nếu cần. Sau đó liệt kê `sources` cho TẤT CẢ trường thực sự có trong `arguments`, kể cả trường tùy chọn; không chỉ cho `device_id` hoặc trường required. Tự so tên key: `set(sources) == set(arguments)`. Thiếu một source thì sửa JSON trước khi xuất.
- Mỗi source phải đúng định dạng nguồn chung ở cuối prompt. `origin` nằm trong object của từng argument, không thay thế key `sources`. ID từ kết quả tool phải trỏ trực tiếp tới ID đó trong `tool_observations`, không suy từ tên thiết bị hoặc tọa độ.
- Với nguồn input, giá trị phải có nguyên văn trong quote; nếu cần chuẩn hóa, đổi ngày tương đối hoặc tính toán, dùng origin=derived kèm inputs và rule.
- Trước write call, bảo đảm mỗi ID và số tiền có căn cứ theo thứ tự **request, context, history, tool response**. Chọn ID và số tiền từ đúng cùng bản ghi khi chúng mô tả một đối tượng; không lấy số tiền của bản ghi khác.
- Đọc mô tả tool và kết quả tra cứu để hiểu ý nghĩa nghiệp vụ. Không suy diễn một hành động có tên gần giống yêu cầu là cùng mục đích.
- Khi tool trả done=false hoặc ok=false, yêu cầu chưa hoàn thành. Đọc lý do rồi chọn bước giải quyết, không lặp lại cùng call hay gọi write tool không liên quan.
- Nếu biết tool đích nhưng tham số bắt buộc không thể lấy từ request/history/context hay read/search tool: ask. Chỉ hỏi required hoặc x-one-of của tool đích.
- Nếu read tool không cần tham số bắt buộc, hãy CALL với arguments={} và sources={}; không ASK để lấy bộ lọc hay tên đối tượng.
- Các call trong history đã áp dụng vào trạng thái ban đầu; không chạy lại. Không đọc state.json.
- Argument phải đúng schema (required, enum, format, x-one-of). Dùng current_time/timezone khi suy ra thời gian.
- Nếu có validation_feedback, xử lý đúng lý do: tra cứu, sửa tham số, chọn lại tool, ask hoặc done.
""" + "\n" + SOURCE_FORMAT


def parse_action(text):
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            obj, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and obj.get("type") in ("call", "ask", "done"):
            return obj
    return None


def missing_fields(spec, args):
    args = args if isinstance(args, dict) else {}
    params = spec.get("parameters") or {}
    empty = (None, "", [], {})
    missing = [key for key in params.get("required", []) if args.get(key) in empty]
    groups = params.get("x-one-of") or []
    if groups and not any(all(args.get(key) not in empty for key in group) for group in groups):
        missing.extend(groups[0])
    return sorted(set(missing))


def valid_ask(name, params, specs):
    if name not in specs or name == "sys.ask_missing_info":
        return False
    if not isinstance(params, list) or not params or not all(isinstance(p, str) for p in params):
        return False
    schema = specs[name].get("parameters") or {}
    required = set(schema.get("required", []))
    for group in schema.get("x-one-of") or []:
        required.update(group)
    return set(params) <= required


def argument_free_call(spec, args):
    """True when an empty call has no required or one-of arguments."""
    params = spec.get("parameters") or {}
    return not args and not params.get("required") and not params.get("x-one-of")


class Agent:
    def __init__(self, llm, catalog, ToolEnv, root, max_tool_calls=10,
                 max_decisions=24, max_repairs=3, max_prompt_tokens=14500,
                 max_new_tokens=384, max_no_progress=2):
        self.llm = llm
        self.catalog = catalog
        self.ToolEnv = ToolEnv
        self.root = root
        self.max_tool_calls = max_tool_calls
        self.max_decisions = max_decisions
        self.max_repairs = max_repairs
        self.max_prompt_tokens = max_prompt_tokens
        self.max_new_tokens = max_new_tokens
        self.max_no_progress = max_no_progress

    def messages(self, row, transcript, observations, feedback):
        context = {key: value for key, value in row["context"].items() if key != "installed_apps"}
        specs = allowed_specs(row, self.catalog)
        history = compact_history(row.get("history") or [])
        observed = []
        for index, item in enumerate(observations[-8:], max(0, len(observations) - 8)):
            serialized = dumps(item["result"])
            observed.append({
                "index": index,
                "name": item["name"], "arguments": item["arguments"],
                "result": (item["result"] if len(serialized) <= 12000
                           else serialized[:12000] + " [truncated]"),
            })
        trimmed = False
        while True:
            payload = {
                "request": transcript, "context": context,
                "history": history, "available_tools": specs,
                "executed_calls": [
                    {"name": item["name"], "arguments": item["arguments"]}
                    for item in observations
                ],
                "tool_observations": observed,
                "validation_feedback": feedback,
                "remaining_tool_calls": self.max_tool_calls - len(observations),
            }
            messages = [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": dumps(payload)},
            ]
            tokens = self.llm.count(messages)
            if tokens <= self.max_prompt_tokens:
                return messages, tokens, trimmed
            trimmed = True
            if history:
                history.pop(0)
            elif len(observed) > 1:
                observed.pop(0)
            elif observed and len(dumps(observed[-1]["result"])) > 1500:
                observed[-1]["result"] = dumps(observed[-1]["result"])[:1500] + " [truncated]"
            else:
                raise ValueError(
                    f"Prompt needs {tokens} tokens after safe trimming; tool schemas cannot be dropped"
                )

    def run(self, row, transcript):
        env = self.ToolEnv("train", row["id"], root=self.root)
        specs = {spec["name"]: spec for spec in allowed_specs(row, self.catalog)}
        observations = []
        trace = []
        feedback = None
        repair_streak = 0
        parse_streak = 0
        duplicate_streak = 0
        no_progress_streak = 0
        last_rejection = None
        last_missing_fact_count = None
        known_facts = set()
        prompt_tokens_each = []
        generated_total = 0
        llm_latency = 0.0
        grounding_prompt_tokens_each = []
        grounding_generated_total = 0
        grounding_latency = 0.0
        repairs_total = 0
        invalid_total = 0
        grounding_total = 0
        semantic_total = 0
        unverified_total = 0
        tool_failures = 0
        no_progress_total = 0
        parse_total = 0
        duplicates_total = 0
        any_trim = False
        stop_reason = "decision_limit"
        start = time.perf_counter()
        context = {key: value for key, value in row["context"].items()
                   if key != "installed_apps"}
        history = compact_history(row.get("history") or [])

        def node_payload(action, spec, **extra):
            return {
                "request": transcript, "context": context, "history": history,
                "tool_observations": [
                    {"index": i, **item} for i, item in enumerate(observations)
                ],
                "tool": spec, "action": action, **extra,
            }

        def run_node(node, payload, event, label=None):
            nonlocal generated_total, grounding_generated_total
            nonlocal llm_latency, grounding_latency
            verdict = review_node(
                self.llm, node, payload, self.max_prompt_tokens,
                self.max_new_tokens,
            )
            verdict["node"] = node
            event.setdefault("node_reviews", {})[label or node] = verdict
            usage = verdict.get("usage") or {}
            if usage.get("prompt_tokens"):
                grounding_prompt_tokens_each.append(usage["prompt_tokens"])
                generated_total += usage["generation_tokens"]
                grounding_generated_total += usage["generation_tokens"]
                llm_latency += usage["latency_s"]
                grounding_latency += usage["latency_s"]
            return verdict

        def reject_call(name, args, stage, code, reason, event, grounding):
            nonlocal grounding_total, semantic_total, repairs_total
            nonlocal repair_streak, last_rejection, feedback, stop_reason
            grounding["ok"] = False
            grounding["stage"] = stage
            grounding["issues"].append({
                "code": code, "field": None, "message": reason,
            })
            grounding_total += 1
            if stage in ("relevance", "arguments"):
                semantic_total += 1
            repairs_total += 1
            repair_streak += 1
            rejection = (name, dumps(args), stage, code, len(known_facts))
            repeated = rejection == last_rejection
            last_rejection = rejection
            event["no_new_information"] = repeated
            feedback = {
                "error": "review_rejected" if code.startswith("qwen_")
                         else "invalid_argument_source",
                "tool": name, "submitted_arguments": args,
                "stage": stage, "reason": reason,
                "issues": grounding["issues"],
                "instruction": "Đọc lý do, sửa action hoặc nguồn; read/search có thể là bước tra cứu trước write.",
            }
            event["error"] = feedback
            trace.append(event)
            if repeated or repair_streak >= self.max_repairs:
                stop_reason = "grounding_no_progress"
                return True
            return False

        for decision_number in range(1, self.max_decisions + 1):
            if len(env.get_tool_calls()) >= self.max_tool_calls:
                stop_reason = "tool_limit"
                break
            try:
                messages, _, trimmed = self.messages(
                    row, transcript, observations, feedback
                )
            except ValueError as error:
                trace.append({
                    "decision": decision_number, "event": "context_overflow",
                    "error": str(error),
                })
                stop_reason = "context_overflow"
                break
            any_trim |= trimmed
            output = self.llm.complete(messages, max_new_tokens=self.max_new_tokens)
            prompt_tokens_each.append(output["prompt_tokens"])
            generated_total += output["generation_tokens"]
            llm_latency += output["latency_s"]
            event = {
                "decision": decision_number,
                "prompt_tokens": output["prompt_tokens"],
                "generation_tokens": output["generation_tokens"],
                "llm_latency_s": output["latency_s"],
                "context_trimmed": trimmed,
                "raw_output": output["text"],
            }
            action = parse_action(output["text"])
            event["action"] = action
            if action is None:
                parse_total += 1
                repairs_total += 1
                parse_streak += 1
                feedback = "Không parse được JSON. Chỉ xuất một object call, ask hoặc done."
                event["error"] = feedback
                trace.append(event)
                if parse_streak >= self.max_repairs:
                    stop_reason = "parse_error"
                    break
                continue
            parse_streak = 0

            if action["type"] == "done":
                trace.append(event)
                stop_reason = "done"
                break

            if action["type"] == "ask":
                name, params = action.get("tool_name"), action.get("params")
                if not valid_ask(name, params, specs):
                    target = specs.get(name)
                    if (target and target.get("kind") == "read"
                            and argument_free_call(target, {})):
                        # An ask for a zero-argument read tool is a schema
                        # misunderstanding. Execute its read step after the
                        # same relevance review as any other call.
                        event["auto_corrected_ask"] = {"tool_name": name,
                                                         "invalid_params": params}
                        action = {"type": "call", "name": name,
                                  "arguments": {}, "sources": {}}
                        event["action"] = action
                    else:
                        schema = (target or {}).get("parameters") or {}
                        feedback = {
                            "error": "invalid_ask", "tool": name,
                            "invalid_params": params,
                            "required": schema.get("required", []),
                            "x-one-of": schema.get("x-one-of", []),
                            "instruction": "Chỉ ask required/x-one-of của tool đích. Nếu read tool gọi được với {}, hãy call ngay.",
                        }
                        event["error"] = feedback
                        trace.append(event)
                        repairs_total += 1
                        repair_streak += 1
                        if repair_streak >= self.max_repairs:
                            stop_reason = "invalid_ask"
                            break
                        continue
                else:
                    ask_review = run_node(
                        "missing_params",
                        node_payload(
                            action, specs[name],
                            available_read_tools=[
                                {"name": tool_name,
                                 "description": tool_spec.get("description", "")}
                                for tool_name, tool_spec in specs.items()
                                if tool_spec.get("kind") == "read"
                            ],
                        ), event,
                    )
                    if not ask_review["ok"]:
                        feedback = {
                            "error": "premature_ask", "tool": name,
                            "params": params, "reason": ask_review["reason"],
                            "instruction": "Tra cứu nếu còn cách lấy dữ liệu; chỉ ask khi thực sự không thể tra.",
                        }
                        event["error"] = feedback
                        trace.append(event)
                        repairs_total += 1
                        repair_streak += 1
                        if repair_streak >= self.max_repairs:
                            stop_reason = "ask_no_progress"
                            break
                        continue
                    result = env.call("sys.ask_missing_info", {
                        "tool_name": name, "params": params,
                    })
                    event["tool_result"] = result
                    trace.append(event)
                    stop_reason = "ask_missing_info"
                    break

            name, args = action.get("name"), action.get("arguments")
            if not isinstance(name, str) or not isinstance(args, dict):
                feedback = {"error": "invalid_call_json",
                            "instruction": "call cần name:string và arguments:object."}
                event["error"] = feedback
                trace.append(event)
                repairs_total += 1
                repair_streak += 1
                if repair_streak >= self.max_repairs:
                    stop_reason = "invalid_call_json"
                    break
                continue
            if name not in specs or name == "sys.ask_missing_info":
                feedback = {
                    "error": "unavailable_tool",
                    "instruction": f"{name!r} không được phép gọi trực tiếp. Chọn available_tools hoặc action ask.",
                }
                event["error"] = feedback
                trace.append(event)
                repairs_total += 1
                repair_streak += 1
                if repair_streak >= self.max_repairs:
                    stop_reason = "unavailable_tool"
                    break
                continue

            spec = specs[name]
            no_arguments = argument_free_call(spec, args)
            missing = [] if no_arguments else missing_fields(spec, args)
            if missing:
                event["missing_fields"] = missing
                event["no_new_information"] = (
                    last_missing_fact_count == len(known_facts)
                )
                last_missing_fact_count = len(known_facts)
                missing_review = run_node(
                    "missing_params",
                    node_payload(
                        action, spec, missing_fields=missing,
                        available_read_tools=[
                            {"name": tool_name,
                             "description": tool_spec.get("description", "")}
                            for tool_name, tool_spec in specs.items()
                            if tool_spec.get("kind") == "read"
                        ],
                    ), event,
                )
                reason = missing_review["reason"] or (
                    "Thiếu tham số bắt buộc: " + ", ".join(missing)
                )
                feedback = {
                    "error": "missing_required_arguments", "tool": name,
                    "missing_fields": missing, "reason": reason,
                    "no_new_information": event["no_new_information"],
                    "instruction": "Tra read/search nếu còn cách; chỉ ask khi không thể lấy tham số bắt buộc.",
                }
                event["error"] = feedback
                repairs_total += 1
                repair_streak += 1
                if repair_streak >= self.max_repairs:
                    ask_action = {"type": "ask", "tool_name": name,
                                  "params": missing}
                    ask_review = run_node(
                        "missing_params",
                        node_payload(
                            ask_action, spec,
                            available_read_tools=[
                                {"name": tool_name,
                                 "description": tool_spec.get("description", "")}
                                for tool_name, tool_spec in specs.items()
                                if tool_spec.get("kind") == "read"
                            ],
                        ), event, label="missing_params_auto_ask",
                    )
                    if valid_ask(name, missing, specs) and ask_review["ok"]:
                        event["auto_ask"] = ask_action
                        event["tool_result"] = env.call(
                            "sys.ask_missing_info",
                            {"tool_name": name, "params": missing},
                        )
                        trace.append(event)
                        stop_reason = "ask_missing_info"
                        break
                    event["ask_review_reject_reason"] = ask_review["reason"]
                    trace.append(event)
                    stop_reason = "missing_no_progress"
                    break
                trace.append(event)
                continue

            grounding = {
                "ok": True, "stage": "relevance" if no_arguments else "schema",
                "issues": [],
                "evidence": {}, "unverified_fields": [],
                "review": None, "reviewed_sources": None, "usage": {},
            }
            event["grounding"] = grounding
            if no_arguments:
                grounding["source_check"] = "skipped_no_arguments"
                event["validation"] = {"ok": True, "error": None,
                                       "skipped": "no_arguments"}
            else:
                schema_review = run_node(
                    "schema",
                    node_payload(action, {"name": name,
                                          "parameters": spec.get("parameters") or {}}),
                    event,
                )
                if not schema_review["ok"]:
                    invalid_total += 1
                    if reject_call(name, args, "schema", "qwen_rejected_schema",
                                   schema_review["reason"], event, grounding):
                        break
                    continue
                validation = env.validate(name, args)
                event["validation"] = validation
                if not validation["ok"]:
                    invalid_total += 1
                    repairs_total += 1
                    repair_streak += 1
                    feedback = {
                        "error": "invalid_schema", "tool": name,
                        "submitted_arguments": args,
                        "schema_error": validation["error"],
                        "missing_fields": missing_fields(spec, args),
                        "instruction": "Sửa arguments theo schema; không đoán giá trị.",
                    }
                    event["error"] = feedback
                    trace.append(event)
                    if repair_streak >= self.max_repairs:
                        stop_reason = "validation_no_progress"
                        break
                    continue

                grounding["stage"] = "sources"
                planner_source = check_sources(
                    action, spec, transcript, context, history, observations,
                )
                grounding["evidence"]["planner"] = planner_source["evidence"]
                grounding["issues"].extend(planner_source["issues"])
                if not planner_source["ok"]:
                    if reject_call(name, args, "sources", "invalid_planner_source",
                                   planner_source["issues"][0]["message"],
                                   event, grounding):
                        break
                    continue

                source_review = run_node(
                    "argument_sources",
                    node_payload(action, {key: spec.get(key) for key in
                                          ("name", "kind", "description")}),
                    event,
                )
                grounding["reviewed_sources"] = source_review["sources"]
                if not source_review["ok"]:
                    if reject_call(name, args, "sources", "qwen_rejected_source",
                                   source_review["reason"], event, grounding):
                        break
                    continue
                reviewed_action = {**action, "sources": source_review["sources"]}
                reviewed_source = check_sources(
                    reviewed_action, spec, transcript, context, history,
                    observations,
                )
                grounding["evidence"]["reviewer"] = reviewed_source["evidence"]
                grounding["unverified_fields"] = sorted(set(
                    planner_source["unverified_fields"]
                    + reviewed_source["unverified_fields"]
                ))
                grounding["issues"].extend(reviewed_source["issues"])
                if not reviewed_source["ok"]:
                    if reject_call(name, args, "sources", "invalid_reviewed_source",
                                   reviewed_source["issues"][0]["message"],
                                   event, grounding):
                        break
                    continue

            grounding["stage"] = "relevance"
            relevance = run_node(
                "relevance",
                node_payload(action, {key: spec.get(key) for key in
                                      ("name", "kind", "description", "returns")}),
                event,
            )
            grounding["review"] = relevance["review"]
            grounding["usage"] = relevance["usage"]
            if not relevance["ok"]:
                if reject_call(name, args, "relevance", "qwen_rejected_call",
                               relevance["reason"], event, grounding):
                    break
                continue

            if not no_arguments:
                grounding["stage"] = "arguments"
                argument_review = run_node(
                    "arguments",
                    node_payload(
                        action, {key: spec.get(key) for key in
                                 ("name", "kind", "description", "returns")},
                        verified_sources=grounding["evidence"],
                    ), event,
                )
                if not argument_review["ok"]:
                    if reject_call(name, args, "arguments", "qwen_rejected_argument",
                                   argument_review["reason"], event, grounding):
                        break
                    continue
            grounding["stage"] = "complete"

            call_key = (name, json.dumps(args, ensure_ascii=False, sort_keys=True))
            previous_keys = {
                (item["name"], json.dumps(item["arguments"], ensure_ascii=False, sort_keys=True))
                for item in observations
            }
            if call_key in previous_keys:
                duplicate_streak += 1
                duplicates_total += 1
                feedback = {
                    "error": "duplicate_call",
                    "instruction": "Call này đã chạy. Dùng tool response hiện có và chọn bước mới hoặc done.",
                }
                event["error"] = feedback
                trace.append(event)
                if duplicate_streak >= self.max_no_progress:
                    stop_reason = "duplicate_no_progress"
                    break
                continue

            unverified_total += len(grounding["unverified_fields"])
            result = env.call(name, args)
            event["tool_result"] = result
            succeeded = result_succeeded(result)
            event["tool_succeeded"] = succeeded
            new_facts = result_facts(result) - known_facts
            known_facts.update(new_facts)
            event["new_fact_count"] = len(new_facts)
            observations.append({
                "name": name, "arguments": args, "result": result,
            })
            trace.append(event)
            repair_streak = 0
            duplicate_streak = 0
            last_rejection = None
            last_missing_fact_count = None
            if not succeeded:
                tool_failures += 1
                no_progress_streak += 1
                feedback = {
                    "error": "tool_not_done",
                    "tool": name, "arguments": args, "result": result,
                    "instruction": "Tool chưa hoàn thành. Dùng lý do thất bại để lập bước khác; không lặp call.",
                }
            elif not new_facts and specs[name].get("kind") == "read":
                no_progress_streak += 1
                no_progress_total += 1
                feedback = {
                    "error": "read_no_new_information",
                    "tool": name, "result": result,
                    "instruction": "Read tool không cung cấp dữ liệu mới. Chọn cách tra khác, ask nếu thiếu tham số bắt buộc không thể tra, hoặc done.",
                }
            else:
                no_progress_streak = 0
                feedback = None
            if no_progress_streak >= self.max_no_progress:
                stop_reason = "no_progress"
                break
        else:
            stop_reason = "decision_limit"

        calls = env.get_tool_calls()
        review_counts = Counter()
        rejection_counts = Counter()
        for event in trace:
            for review in (event.get("node_reviews") or {}).values():
                node = review.get("node")
                if node:
                    review_counts[node] += 1
                    if not review.get("ok"):
                        rejection_counts[node] += 1
        return {
            "id": row["id"], "transcript": transcript,
            "tool_calls": calls, "state_hash": env.get_state_hash(),
            "stop_reason": stop_reason, "decisions": len(trace),
            "tool_iterations": len(calls), "repair_attempts": repairs_total,
            "invalid_schema_proposals": invalid_total,
            "grounding_rejections": grounding_total,
            "semantic_rejections": semantic_total,
            "unverified_arguments": unverified_total,
            "tool_failures": tool_failures,
            "no_progress_events": no_progress_total,
            "parse_errors": parse_total, "duplicate_proposals": duplicates_total,
            "prompt_tokens_each": prompt_tokens_each,
            "grounding_prompt_tokens_each": grounding_prompt_tokens_each,
            "grounding_reviews": len(grounding_prompt_tokens_each),
            "node_review_counts": dict(review_counts),
            "node_rejections": dict(rejection_counts),
            "grounding_generation_tokens_total": grounding_generated_total,
            "grounding_llm_latency_s": grounding_latency,
            "prompt_tokens_total": sum(prompt_tokens_each) + sum(grounding_prompt_tokens_each),
            "prompt_tokens_max": max(prompt_tokens_each + grounding_prompt_tokens_each, default=0),
            "generation_tokens_total": generated_total,
            "llm_latency_s": llm_latency,
            "agent_latency_s": time.perf_counter() - start,
            "context_trimmed": any_trim,
            "trace": trace,
        }
