"""Focused v2 checks using the real train ToolEnv, without loading models."""
from __future__ import annotations

import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "train+public_test"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "train"))

from agent import Agent  # noqa: E402
from common import agent_summary, evaluate_agent_case, load_catalog  # noqa: E402
from grounding import request_numbers, result_succeeded, verify_call  # noqa: E402
from grounding_qwen import check_sources  # noqa: E402
from node_reviews import SYSTEMS, review_node  # noqa: E402
from source_contract import SOURCE_FORMAT  # noqa: E402
from zaic_tools import ToolEnv  # noqa: E402


def train_0015():
    with (ROOT / "train" / "train.jsonl").open(encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            if row["id"] == "train_0015":
                return row
    raise AssertionError("train_0015 not found")


class ScriptedLLM:
    model_id = "scripted-test"

    def __init__(self, actions):
        self.actions = iter(actions)
        self.prompts = []

    def count(self, messages):
        return 100

    def complete(self, messages, max_new_tokens=256):
        self.prompts.append(messages)
        system = messages[0]["content"]
        if system.startswith("Bạn review node"):
            payload = json.loads(messages[1]["content"])
            proposal = payload["action"]
            arguments = proposal.get("arguments") or {}
            name = proposal.get("name")
            if "THIẾU THAM SỐ" in system:
                missing = payload.get("missing_fields") or []
                answer = ({"reject_reason": "Thiếu " + ", ".join(missing)}
                          if missing else {})
            elif "TOOL PHÙ HỢP" in system:
                answer = ({"reject_reason": "sai mục tiêu"}
                          if name == "banking.open_savings" else {})
            elif "NGUỒN ARGUMENT" in system:
                answer = {"sources": proposal.get("sources") or {}}
            elif "GIÁ TRỊ ARGUMENT" in system:
                reason = None
                if name == "banking.transfer" and arguments.get("from_account_id") == "acc_01":
                    reason = "số dư tài khoản không đủ"
                if (name == "banking.transfer"
                        and str(arguments.get("amount")) not in ("None", "218000")):
                    reason = "số tiền không thuộc hóa đơn internet"
                answer = {"reject_reason": reason} if reason else {}
            else:
                answer = {}
        else:
            answer = next(self.actions)
        return {
            "text": json.dumps(answer, ensure_ascii=False),
            "prompt_tokens": 100, "generation_tokens": 20, "latency_s": 0.01,
        }


def result_source(index, path):
    return {"origin": "previous_tool_calls", "index": index,
            "part": "result", "path": path}


def call(name, sources=None, **arguments):
    return {"type": "call", "name": name, "arguments": arguments,
            "sources": sources if sources is not None else {}}


class GroundedWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.row = train_0015()
        cls.catalog = load_catalog(ROOT)

    def run_actions(self, actions):
        agent = Agent(
            ScriptedLLM(actions), self.catalog, ToolEnv, ROOT,
            max_tool_calls=10, max_decisions=12, max_repairs=3,
        )
        return agent.run(self.row, self.row["audio_text"])

    def test_gold_path_replays_exactly(self):
        outcome = self.run_actions([
            call("bill_payment.list_bills"),
            call("banking.get_balance"),
            call("banking.list_beneficiaries"),
            call("banking.transfer", from_account_id="acc_02",
                 beneficiary_id="ben_02", amount=218000,
                 sources={"from_account_id": result_source(1, "accounts[1].id"),
                          "beneficiary_id": result_source(2, "beneficiaries[1].id"),
                          "amount": result_source(0, "bills[2].amount")}),
            {"type": "done"},
        ])
        case = evaluate_agent_case(
            self.row, outcome, ROOT, self.catalog, ToolEnv
        )
        self.assertTrue(case["state_hash_match"])
        self.assertEqual(
            agent_summary([case])["grounding_rejections_per_sample"]["max"], 0
        )
        self.assertEqual(case["score_proxy"], 1.0)
        self.assertEqual(outcome["grounding_rejections"], 0)
        transfer = outcome["trace"][3]
        self.assertEqual(list(transfer["node_reviews"]),
                         ["schema", "argument_sources", "relevance", "arguments"])
        self.assertEqual(
            transfer["grounding"]["reviewed_sources"]["amount"]["origin"],
            "previous_tool_calls",
        )

    def test_fabricated_amount_is_blocked_before_tool_call(self):
        outcome = self.run_actions([
            call("banking.list_beneficiaries"),
            call("banking.get_balance"),
            call("banking.transfer", from_account_id="acc_01",
                 beneficiary_id="ben_02", amount=1000000,
                 sources={"from_account_id": result_source(1, "accounts[0].id"),
                          "beneficiary_id": result_source(0, "beneficiaries[1].id"),
                          "amount": {"origin": "input", "quote": "tiền mạng tháng này"}}),
            call("bill_payment.list_bills"),
            call("banking.transfer", from_account_id="acc_02",
                 beneficiary_id="ben_02", amount=218000,
                 sources={"from_account_id": result_source(1, "accounts[1].id"),
                          "beneficiary_id": result_source(0, "beneficiaries[1].id"),
                          "amount": result_source(2, "bills[2].amount")}),
            {"type": "done"},
        ])
        self.assertEqual(outcome["grounding_rejections"], 1)
        self.assertEqual(len(outcome["tool_calls"]), 4)
        blocked = [e for e in outcome["trace"]
                   if (e.get("action") or {}).get("name") == "banking.transfer"
                   and e["action"]["arguments"]["amount"] == 1000000]
        self.assertEqual(len(blocked), 1)
        self.assertFalse(blocked[0]["grounding"]["ok"])
        self.assertNotIn("tool_result", blocked[0])
        case = evaluate_agent_case(
            self.row, outcome, ROOT, self.catalog, ToolEnv
        )
        self.assertTrue(case["state_hash_match"])
        self.assertEqual(
            agent_summary([case])["grounding_rejections_per_sample"]["max"], 1
        )

    def test_open_savings_wrong_goal_is_rejected(self):
        outcome = self.run_actions([
            call("banking.get_balance"),
            call("banking.open_savings", from_account_id="acc_02",
                 amount=1000000, term_months=1,
                 sources={"from_account_id": result_source(0, "accounts[1].id"),
                          "amount": {"origin": "derived", "rule": "đề xuất gửi một triệu",
                                     "inputs": [{"origin": "input", "quote": "tiết kiệm"}]},
                          "term_months": {"origin": "derived", "rule": "kỳ hạn một tháng",
                                          "inputs": [{"origin": "input", "quote": "tháng này"}]}}),
            {"type": "done"},
        ])
        issues = outcome["trace"][1]["grounding"]["issues"]
        self.assertIn("qwen_rejected_call", [x["code"] for x in issues])
        self.assertEqual(len(outcome["tool_calls"]), 1)

    def test_existing_account_id_can_still_be_wrong_choice(self):
        outcome = self.run_actions([
            call("bill_payment.list_bills"),
            call("banking.get_balance"),
            call("banking.list_beneficiaries"),
            call("banking.transfer", from_account_id="acc_01",
                 beneficiary_id="ben_02", amount=218000,
                 sources={"from_account_id": result_source(1, "accounts[0].id"),
                          "beneficiary_id": result_source(2, "beneficiaries[1].id"),
                          "amount": result_source(0, "bills[2].amount")}),
            {"type": "done"},
        ])
        issues = outcome["trace"][3]["grounding"]["issues"]
        self.assertIn("qwen_rejected_argument", [x["code"] for x in issues])
        self.assertEqual(len(outcome["tool_calls"]), 3)

    def test_real_amount_from_wrong_bill_is_rejected_by_qwen(self):
        outcome = self.run_actions([
            call("bill_payment.list_bills"),
            call("banking.get_balance"),
            call("banking.list_beneficiaries"),
            call("banking.transfer", from_account_id="acc_02",
                 beneficiary_id="ben_02", amount=846000,
                 sources={"from_account_id": result_source(1, "accounts[1].id"),
                          "beneficiary_id": result_source(2, "beneficiaries[1].id"),
                          "amount": result_source(0, "bills[3].amount")}),
            call("banking.transfer", from_account_id="acc_02",
                 beneficiary_id="ben_02", amount=218000,
                 sources={"from_account_id": result_source(1, "accounts[1].id"),
                          "beneficiary_id": result_source(2, "beneficiaries[1].id"),
                          "amount": result_source(0, "bills[2].amount")}),
            {"type": "done"},
        ])
        wrong = outcome["trace"][3]
        self.assertEqual(wrong["grounding"]["stage"], "arguments")
        self.assertIn("qwen_rejected_argument",
                      [issue["code"] for issue in wrong["grounding"]["issues"]])
        self.assertNotIn("tool_result", wrong)
        self.assertTrue(wrong["validation"]["ok"])
        self.assertEqual(len(outcome["tool_calls"]), 4)

    def test_every_argument_requires_existing_source_path(self):
        outcome = self.run_actions([
            call("banking.get_balance"),
            call("banking.transfer", from_account_id="acc_02",
                 beneficiary_id="ben_02", amount=218000,
                 sources={"from_account_id": result_source(0, "accounts[99].id"),
                          "beneficiary_id": result_source(0, "accounts[1].id"),
                          "amount": result_source(0, "accounts[1].balance")}),
            {"type": "done"},
        ])
        issues = outcome["trace"][1]["grounding"]["issues"]
        self.assertIn("invalid_source", [issue["code"] for issue in issues])
        self.assertIn("source_value_mismatch", [issue["code"] for issue in issues])
        self.assertGreaterEqual(outcome["grounding_reviews"], 2)
        self.assertTrue(outcome["trace"][1]["validation"]["ok"])

    def test_missing_source_for_argument_blocks_call(self):
        outcome = self.run_actions([
            call("banking.get_balance"),
            call("banking.list_transactions", account_id="acc_02"),
            {"type": "done"},
        ])
        issues = outcome["trace"][1]["grounding"]["issues"]
        self.assertIn("missing_argument_sources", [issue["code"] for issue in issues])
        self.assertEqual(len(outcome["tool_calls"]), 1)

    def test_no_argument_read_skips_sources_and_schema(self):
        outcome = self.run_actions([
            {"type": "call", "name": "banking.list_beneficiaries",
             "arguments": {}},
            {"type": "done"},
        ])
        event = outcome["trace"][0]
        self.assertTrue(event["grounding"]["ok"])
        self.assertEqual(event["grounding"]["source_check"], "skipped_no_arguments")
        self.assertEqual(event["validation"]["skipped"], "no_arguments")
        self.assertEqual(set(event["node_reviews"]), {"relevance"})
        self.assertEqual(len(outcome["tool_calls"]), 1)

    def test_read_lookup_can_precede_missing_transfer_details(self):
        outcome = self.run_actions([
            call("contacts.search", query="Phạm Hùng",
                 sources={"query": {"origin": "input", "quote": "Phạm Hùng"}}),
            {"type": "done"},
        ])
        event = outcome["trace"][0]
        self.assertTrue(event["grounding"]["ok"])
        self.assertEqual(event["grounding"]["review"], {})
        self.assertTrue(event["validation"]["ok"])
        self.assertEqual(outcome["tool_calls"][0]["name"], "contacts.search")

    def test_request_source_cannot_cite_a_different_name(self):
        outcome = self.run_actions([
            call("contacts.search", query="Lê Minh",
                 sources={"query": {"origin": "input", "quote": "Phạm Hùng"}}),
            {"type": "done"},
        ])
        event = outcome["trace"][0]
        self.assertEqual(event["grounding"]["stage"], "sources")
        self.assertIn("source_value_mismatch",
                      [x["code"] for x in event["grounding"]["issues"]])
        self.assertTrue(event["validation"]["ok"])
        self.assertEqual(outcome["tool_calls"], [])

    def test_derived_source_records_a_translation_rule(self):
        check = check_sources(
            {"arguments": {"power": "off"},
             "sources": {"power": {"origin": "derived",
                                   "inputs": [{"origin": "input", "quote": "tắt đèn"}],
                                   "rule": "tắt đèn => power=off"}}},
            {"parameters": {"properties": {"power": {"type": "string"}}}},
            "tắt đèn", {}, [], [],
        )
        self.assertTrue(check["ok"])
        self.assertEqual(check["unverified_fields"], ["power"])

    def test_canonical_sources_cover_input_history_context_and_previous_calls(self):
        action = {
            "arguments": {"query": "Phạm Hùng", "account_id": "acc_02",
                          "nickname": "Sếp Dũng", "beneficiary_id": "ben_02"},
            "sources": {
                "query": {"origin": "input", "quote": "Phạm Hùng"},
                "account_id": {"origin": "context", "path": "account.id"},
                "nickname": {"origin": "history", "path": "[0].text"},
                "beneficiary_id": {"origin": "previous_tool_calls", "index": 0,
                                   "part": "result", "path": "beneficiaries[0].id"},
            },
        }
        result = check_sources(
            action, {}, "Chuyển cho Phạm Hùng",
            {"account": {"id": "acc_02"}},
            [{"text": "Sếp Dũng"}],
            [{"arguments": {}, "result": {"beneficiaries": [{"id": "ben_02"}]}}],
        )
        self.assertTrue(result["ok"], result["issues"])

    def test_legacy_origin_and_scalar_sources_are_rejected(self):
        for source in ({"origin": "request", "quote": "Phạm Hùng"}, "Phạm Hùng"):
            with self.subTest(source=source):
                result = check_sources(
                    {"arguments": {"query": "Phạm Hùng"},
                     "sources": {"query": source}},
                    {}, "Tìm Phạm Hùng", {}, [], [],
                )
                self.assertFalse(result["ok"])
                self.assertEqual(result["issues"][0]["code"], "invalid_source")

    def test_train_0063_uses_history_and_input_sources(self):
        with (ROOT / "train" / "train.jsonl").open(encoding="utf-8") as handle:
            row = next(json.loads(line) for line in handle
                       if json.loads(line)["id"] == "train_0063")
        llm = ScriptedLLM([
            call("sms.send", contact_id="c_10", content="nhớ mang tài liệu",
                 sources={
                     "contact_id": {"origin": "history",
                                    "path": "[1].tool_results[0].contacts[9].id"},
                     "content": {"origin": "input", "quote": "nhớ mang tài liệu"},
                 }),
            {"type": "done"},
        ])
        outcome = Agent(llm, self.catalog, ToolEnv, ROOT).run(row, row["audio_text"])
        case = evaluate_agent_case(row, outcome, ROOT, self.catalog, ToolEnv)
        self.assertTrue(case["state_hash_match"])
        self.assertEqual(case["score_proxy"], 1.0)
        self.assertEqual(outcome["trace"][0]["grounding"]["reviewed_sources"],
                         outcome["trace"][0]["action"]["sources"])

    def test_train_0075_succeeds_with_source_for_every_argument(self):
        with (ROOT / "train" / "train.jsonl").open(encoding="utf-8") as handle:
            row = next(json.loads(line) for line in handle
                       if json.loads(line)["id"] == "train_0075")
        actions = [
            call("smart_home.get_status"),
            call("smart_home.light_set", device_id="light_living", power="on",
                 brightness=50, sources={
                     "device_id": result_source(0, "devices[0].id"),
                     "power": {"origin": "derived", "inputs": [
                         {"origin": "input", "quote": "Bật đèn phòng khách"}],
                         "rule": "bật đèn nghĩa là power=on"},
                     "brightness": {"origin": "input", "quote": "50 phần trăm"},
                 }),
            call("smart_home.climate_set", device_id="ac_living", mode="cool",
                 temperature=26, sources={
                     "device_id": result_source(0, "devices[1].id"),
                     "mode": {"origin": "derived", "inputs": [
                         {"origin": "input", "quote": "bật điều hoà phòng khách 26 độ"}],
                         "rule": "bật điều hoà 26 độ nghĩa là mode=cool"},
                     "temperature": {"origin": "input", "quote": "26 độ"},
                 }),
            {"type": "done"},
        ]
        outcome = Agent(ScriptedLLM(actions), self.catalog, ToolEnv, ROOT).run(
            row, row["audio_text"])
        case = evaluate_agent_case(row, outcome, ROOT, self.catalog, ToolEnv)
        self.assertTrue(case["state_hash_match"])
        self.assertEqual(case["score_proxy"], 1.0)
        self.assertEqual(list(outcome["trace"][1]["node_reviews"]),
                         ["schema", "argument_sources", "relevance", "arguments"])
        self.assertEqual(len(outcome["trace"][1]["action"]["sources"]), 3)

    def test_missing_source_feedback_lists_fields(self):
        result = check_sources(
            {"arguments": {"device_id": "light_living", "power": "on",
                           "brightness": 50},
             "sources": {"device_id": result_source(0, "devices[0].id")}},
            {}, "Bật đèn phòng khách 50 phần trăm", {}, [], [],
        )
        self.assertFalse(result["ok"])
        self.assertIn("brightness", result["issues"][0]["message"])
        self.assertIn("power", result["issues"][0]["message"])

    def test_source_reviewer_requires_exact_argument_keys(self):
        class WrongKeys:
            def count(self, messages):
                return 100

            def complete(self, messages, max_new_tokens=256):
                return {"text": json.dumps({"sources": {
                    "nhắn_tin_cho_minh": {"origin": "input", "quote": "Minh"}}}),
                    "prompt_tokens": 100, "generation_tokens": 20,
                    "latency_s": 0.01}

        verdict = review_node(
            WrongKeys(), "argument_sources",
            {"action": {"arguments": {"query": "Minh"}}}, 1000, 256,
        )
        self.assertFalse(verdict["ok"])
        self.assertIn("query", verdict["reason"])
        self.assertIn("nhắn_tin_cho_minh", verdict["reason"])

    def test_reviewer_origin_is_verified_before_tool_call(self):
        class FabricatedOriginLLM(ScriptedLLM):
            def complete(self, messages, max_new_tokens=256):
                if "NGUỒN ARGUMENT" in messages[0]["content"]:
                    self.prompts.append(messages)
                    return {
                        "text": json.dumps({"sources": {
                            "query": {"origin": "input", "quote": "Lê Minh"},
                        }}),
                        "prompt_tokens": 100, "generation_tokens": 20,
                        "latency_s": 0.01,
                    }
                return super().complete(messages, max_new_tokens)

        llm = FabricatedOriginLLM([
            call("contacts.search", query="Phạm Hùng",
                 sources={"query": {"origin": "input", "quote": "Phạm Hùng"}}),
            {"type": "done"},
        ])
        outcome = Agent(llm, self.catalog, ToolEnv, ROOT,
                        max_decisions=4).run(self.row, self.row["audio_text"])
        event = outcome["trace"][0]
        self.assertEqual(event["grounding"]["stage"], "sources")
        self.assertIn("invalid_source",
                      [issue["code"] for issue in event["grounding"]["issues"]])
        self.assertNotIn("tool_result", event)
        self.assertEqual(outcome["tool_calls"], [])

    def test_schema_review_rejection_returns_short_feedback(self):
        class RejectSchemaLLM(ScriptedLLM):
            def complete(self, messages, max_new_tokens=256):
                if "SCHEMA ARGUMENT" in messages[0]["content"]:
                    self.prompts.append(messages)
                    return {"text": '{"reject_reason":"query sai schema"}',
                            "prompt_tokens": 100, "generation_tokens": 20,
                            "latency_s": 0.01}
                return super().complete(messages, max_new_tokens)

        llm = RejectSchemaLLM([
            call("contacts.search", query="Phạm Hùng",
                 sources={"query": {"origin": "input", "quote": "Phạm Hùng"}}),
            {"type": "done"},
        ])
        outcome = Agent(llm, self.catalog, ToolEnv, ROOT,
                        max_decisions=4).run(self.row, self.row["audio_text"])
        event = outcome["trace"][0]
        self.assertEqual(event["grounding"]["stage"], "schema")
        self.assertEqual(event["error"]["reason"], "query sai schema")
        self.assertEqual(outcome["tool_calls"], [])

    def test_review_prompts_have_no_examples_and_planner_has_format_samples(self):
        self.assertEqual(set(SYSTEMS), {
            "missing_params", "relevance", "argument_sources",
            "arguments", "schema",
        })
        for node, prompt in SYSTEMS.items():
            with self.subTest(node=node):
                self.assertNotIn("Ví dụ", prompt)
                self.assertIn("reject_reason", prompt)
        self.assertIn(SOURCE_FORMAT, SYSTEMS["argument_sources"])
        from agent import SYSTEM
        self.assertIn(SOURCE_FORMAT, SYSTEM)
        for origin in ("input", "context", "history", "previous_tool_calls",
                       "derived", "schema"):
            self.assertIn(f'"origin":"{origin}"', SOURCE_FORMAT)
        self.assertIn("Enum tiếng Anh suy từ từ tiếng Việt", SOURCE_FORMAT)
        self.assertIn("không ghi lại `result.`", SOURCE_FORMAT)
        self.assertNotIn("Ví dụ", SOURCE_FORMAT)
        self.assertIn('{"type":"call","name":"<available_tool_name>"', SYSTEM)
        self.assertIn('{"type":"ask","tool_name":"<target_tool_name>"', SYSTEM)
        self.assertIn('{"type":"done"}', SYSTEM)
        self.assertIn('"<field_b>":{"origin":"previous_tool_calls"', SYSTEM)
        self.assertIn("set(sources) == set(arguments)", SYSTEM)

    def test_review_reject_reason_is_short(self):
        class LongReview:
            def count(self, messages):
                return 100

            def complete(self, messages, max_new_tokens=96):
                return {"text": json.dumps({"reject_reason": "sai " * 60}),
                        "prompt_tokens": 100, "generation_tokens": 40,
                        "latency_s": 0.01}

        verdict = review_node(
            LongReview(), "relevance", {"action": {"arguments": {}}},
            1000, 96,
        )
        self.assertFalse(verdict["ok"])
        self.assertLessEqual(len(verdict["reason"].split()), 20)

    def test_rejection_reason_enters_next_planner_context(self):
        llm = ScriptedLLM([
            call("contacts.search", query="Lê Minh",
                 sources={"query": {"origin": "input", "quote": "Phạm Hùng"}}),
            {"type": "done"},
        ])
        agent = Agent(llm, self.catalog, ToolEnv, ROOT, max_decisions=4)
        agent.run(self.row, self.row["audio_text"])
        next_input = json.loads(llm.prompts[-1][1]["content"])
        self.assertEqual(next_input["validation_feedback"]["error"],
                         "invalid_argument_source")
        self.assertIn("Chuỗi argument", next_input["validation_feedback"]["reason"])

    def test_empty_arguments_do_not_bypass_required_schema(self):
        outcome = self.run_actions([
            call("banking.transfer"),
            {"type": "done"},
        ])
        event = outcome["trace"][0]
        self.assertEqual(event["missing_fields"], ["amount", "beneficiary_id", "from_account_id"])
        self.assertEqual(event["error"]["error"], "missing_required_arguments")
        self.assertEqual(outcome["tool_calls"], [])

    def test_invalid_ask_for_argument_free_read_becomes_call(self):
        outcome = self.run_actions([
            {"type": "ask", "tool_name": "banking.list_beneficiaries",
             "params": ["beneficiary_name"]},
            {"type": "done"},
        ])
        event = outcome["trace"][0]
        self.assertEqual(event["action"]["type"], "call")
        self.assertEqual(event["action"]["arguments"], {})
        self.assertIn("auto_corrected_ask", event)
        self.assertEqual(outcome["tool_calls"][0]["name"],
                         "banking.list_beneficiaries")

    def test_schema_validation_runs_before_sources_and_relevance(self):
        outcome = self.run_actions([
            call("bill_payment.list_bills"),
            call("banking.get_balance"),
            call("banking.list_beneficiaries"),
            call("banking.transfer", from_account_id="acc_02",
                 beneficiary_id="ben_02", amount="218000",
                 sources={"from_account_id": result_source(1, "accounts[1].id"),
                          "beneficiary_id": result_source(2, "beneficiaries[1].id"),
                          "amount": result_source(0, "bills[2].amount")}),
            {"type": "done"},
        ])
        event = outcome["trace"][3]
        self.assertEqual(event["grounding"]["stage"], "schema")
        self.assertTrue(event["grounding"]["ok"])
        self.assertFalse(event["validation"]["ok"])
        self.assertEqual(event["error"]["error"], "invalid_schema")
        self.assertEqual(list(event["node_reviews"]), ["schema"])

    def test_response_and_common_money_phrases(self):
        self.assertFalse(result_succeeded({"ok": True, "done": False}))
        self.assertIn(2_000_000, request_numbers("chuyển hai triệu"))
        self.assertIn(500_000, request_numbers("chuyển năm trăm nghìn"))
        self.assertIn(1_000_000, request_numbers("chuyển 1.000.000 đồng"))
        self.assertIn(218_000, request_numbers("trả 218000 đồng"))

    def test_record_linking_is_app_agnostic(self):
        spec = {
            "kind": "write", "parameters": {"properties": {
                "product_id": {"type": "string", "x-ref": "shop.products"},
                "amount": {"type": "integer"},
            }}
        }
        observations = [{
            "name": "shop.list_products", "arguments": {},
            "result": {"products": [
                {"id": "p1", "amount": 75},
                {"id": "p2", "amount": 90},
            ]},
        }]
        specs = {"shop.list_products": {
            "kind": "read", "returns": "products[]"},
                 "shop.buy": spec}
        good = verify_call("shop.buy", {"product_id": "p2", "amount": 90},
                           spec, "mua p2", {}, [], observations, specs)
        bad = verify_call("shop.buy", {"product_id": "p2", "amount": 75},
                          spec, "mua p2", {}, [], observations, specs)
        self.assertTrue(good["ok"])
        self.assertEqual(good["evidence"]["amount"]["record_linked_by"],
                         "product_id")
        self.assertIn("cross_record_argument",
                      [issue["code"] for issue in bad["issues"]])


if __name__ == "__main__":
    unittest.main()
