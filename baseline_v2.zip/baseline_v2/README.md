# LifeMate baseline v2

This folder is an independent experiment. It keeps PhoWhisper-medium, Qwen3-4B-Instruct-2507, vLLM/Transformers adapters, and the three v1 experiment modes. It writes to a separate output folder, so v1 results remain available for comparison.

## Workflow and review nodes

`agent.py` builds on the [reference workflow image](workflow_from_reference.png). The Mermaid diagram below shows the implemented node order, including the separate argument-value and schema reviews. The planner system prompt contains JSON format samples for `call`, `ask`, and `done`; the five review prompts in [node_reviews.py](node_reviews.py) specify rules and output contracts without examples.

1. PhoWhisper transcribes audio. For the workflow-only experiment, the agent receives the gold transcript instead.
2. Qwen planner chooses exactly one `call`, `ask`, or `done`. For `call`, it reads the selected tool's `parameters.properties`, constructs `arguments`, then supplies `sources` for every argument key, including optional arguments. It checks `set(sources) == set(arguments)` before output. `done` handles unclear/out-of-scope/completed requests; this is a planner decision, not a separate hidden-state check.
3. Code checks tool availability and required/x-one-of fields. If a proposed call lacks required fields, Qwen's **missing_params** prompt gives a short reason. The reason enters `validation_feedback`; after three unresolved attempts the agent asks only if Qwen confirms no useful lookup remains. A proposed `ask` goes through the same prompt and is rejected if read/search can find the value. An invalid `ask` for a zero-argument read tool is converted into `call {}`.
4. For a call with arguments, Qwen's **schema** review checks type/enum/format and permitted fields, then `env.validate()` checks the schema. Both run before source and relevance review.
5. Code checks the planner's citations. Qwen's **argument_sources** review independently returns the same `sources` format: `{"sources":{"field":{"origin":"input","quote":"..."}}}` (or a short `reject_reason`). The shared contract is in [source_contract.py](source_contract.py). Both maps must have exactly the same keys as `arguments`; only `input`, `context`, `history`, `previous_tool_calls`, `derived`, and `schema` are accepted as origins. If keys are missing, feedback names the fields. Code verifies both sets of citations against visible input, context, history and previous tool calls. `derived` values require inputs and a rule; their arithmetic/semantic result remains a model judgment.
6. Qwen's **relevance** review checks whether the tool is a useful next step. A read/search step need not finish the user's request. It returns `{}` or `{"reject_reason":"..."}`.
7. Qwen's **arguments** review checks whether the values refer to the correct person, record, amount and condition. It returns `{}` or a short `reject_reason`. If `arguments={}` is allowed by the schema, the call skips schema/source/argument reviews and only goes through relevance.
8. A valid, nonduplicate call reaches `env.call()`. Its result and any failure/no-new-information feedback enter the next planner input. The planner decides whether to continue or `done`; tool, decision, repair and no-progress limits stop loops.

Rejection reasons are capped at 20 words by code. `traces.jsonl` stores `node_reviews`, the planner's sources, Qwen's `reviewed_sources`, deterministic evidence, validation and tool results. `cases.csv` and `summary.json` include `node_review_counts` and `node_rejections`. `grounding_reviews`, `grounding_prompt_tokens_each`, and `grounding_llm_latency_s` now include all Qwen review calls; `grounding_rejections` counts blocked calls. One ToolEnv is used per sample; labels and `state.json` are not used for planning.

```mermaid
flowchart TD
    A[Qwen planner: action + sources] --> T{call / ask / done}
    T -- done --> I[Return calls + state hash]
    T -- ask --> AM[Qwen missing-params review]
    AM -- approved --> ASK[sys.ask_missing_info] --> I
    AM -- rejected --> F[Reason in validation_feedback]
    T -- call --> M{Required arguments missing?}
    M -- yes --> MR[Qwen missing-params review] --> F
    M -- no --> C{Empty arguments allowed?}
    C -- yes --> B{Qwen: tool useful next?}
    C -- no --> SR{Qwen: schema valid?}
    SR -- no --> F
    SR -- yes --> SV{env.validate valid?}
    SV -- no --> F
    SV -- yes --> D{Planner sources exist and match?}
    D -- no --> F
    D -- yes --> QR[Qwen returns independent sources]
    QR -- rejected or invalid source --> F
    QR -- valid --> B
    B -- no --> F
    B -- yes --> H{Has arguments?}
    H -- no --> E[env.call]
    H -- yes --> AR{Qwen: argument values correct?}
    AR -- no --> F
    AR -- yes --> E
    F --> R{Repair limit reached?}
    R -- no --> A
    R -- yes --> I
    E --> G[Tool result + progress feedback in context]
    G --> A
```

Example action after `bill_payment.list_bills`, `banking.get_balance`, and `banking.list_beneficiaries`:

```json
{"type":"call","name":"banking.transfer","arguments":{"from_account_id":"acc_02","beneficiary_id":"ben_02","amount":218000},"sources":{"from_account_id":{"origin":"previous_tool_calls","index":1,"part":"result","path":"accounts[1].id"},"beneficiary_id":{"origin":"previous_tool_calls","index":2,"part":"result","path":"beneficiaries[1].id"},"amount":{"origin":"previous_tool_calls","index":0,"part":"result","path":"bills[2].amount"}}}
```

For calculated values, use `{"origin":"derived","inputs":[...],"rule":"..."}`. Code verifies the inputs exist; Qwen judges the semantic result. These reviews use the **same Qwen model** as the planner, so their mistakes may be correlated. A call with arguments can cost four additional Qwen inferences (relevance, source, argument, schema), and a call with missing fields invokes the missing-parameter review. The older rule-based `grounding.py`, `domain_rules.py`, and `audit_grounding.py` remain comparison code; only generic source helpers from `grounding.py` are reused live.

## Experiments

- `asr`: audio → PhoWhisper transcript; WER/CER and ASR timing.
- `workflow`: gold `audio_text` → Qwen agent and ToolEnv.
- `baseline`: PhoWhisper transcript → the same agent and ToolEnv.
- `all`: run all three on identical sampled train IDs.

## Kaggle

Attach the extracted `train+public_test` folder and `baseline_v2` folder as Kaggle inputs. Enable GPU and Internet for initial model downloads. Open [kaggle_runner.ipynb](kaggle_runner.ipynb), set `DATA_ROOT` if autodetection cannot find your data, and run the cells. Use `MODE="workflow"` to test the agent without ASR first, then `MODE="all"`. `LIMIT=0` means all train samples.

The notebook installs `requirements-vllm.txt` for the vLLM backend. Its default `TRITON_ATTN` and `float16` settings support Kaggle Tesla T4 and avoid the FlashInfer linker/BF16 errors seen in v1. PhoWhisper reads PCM16 WAV directly rather than using the Transformers ASR pipeline, avoiding a TorchCodec dependency. ASR and Qwen are loaded sequentially to limit peak VRAM.

Command line equivalent:

```bash
python -m pip install -r baseline_v2/requirements-vllm.txt
python baseline_v2/run.py --mode workflow --data-root train+public_test --limit 50 --output-dir /kaggle/working/lifemate_baseline_v2
python baseline_v2/run.py --mode all --data-root train+public_test --limit 50 --output-dir /kaggle/working/lifemate_baseline_v2
```

Useful limits: `--max-tool-calls 10`, `--max-decisions 24`, `--max-repairs 3`, `--max-no-progress 2`, `--max-prompt-tokens 11500`, `--max-new-tokens 256`. The default vLLM model context is 12288 tokens. Use `--llm-backend transformers` with `requirements.txt` for a separate backend comparison.

Qwen defaults to `--llm-temperature 0.7` on both backends, with `top_p=0.8` and `top_k=20`. Set `--llm-temperature 0` to use greedy decoding. `--seed 42` controls sample selection, Python hashing, Python/NumPy/PyTorch RNGs, and the Qwen sampler. PhoWhisper uses non-sampling decoding. The runner sets `CUBLAS_WORKSPACE_CONFIG=:4096:8`, disables cuDNN benchmarking, requests deterministic PyTorch algorithms where available, and disables vLLM V1 multiprocessing for deterministic offline scheduling. Direct `run.py` invocation restarts once if the process hash seed is not already correct; the Kaggle notebook passes the environment explicitly. Cached ASR predictions are reused only for the same model, batch size and seed.

The seed, settings, and package versions are recorded in `run_config.json`; workflow and ASR summaries also record the seed. Compare outputs on the same hardware with the same package versions, model revision, data, mode and inference settings. A fixed seed with temperature 0.7 makes sampling repeatable under those conditions, but does not guarantee identical results across different GPUs or software versions. Timing measurements will still vary. PyTorch's deterministic setting uses warning mode so unsupported operations do not stop a Kaggle run; treat any such warning as a reproducibility limit.

## Results

The output directory defaults to `/kaggle/working/lifemate_baseline_v2` on Kaggle. It contains:

- `asr/`: predictions, WER/CER cases, summary, report, chart.
- `workflow_gold/` and `baseline_asr/`: predictions, per-sample cases, traces, summary, report, chart.
- `comparison.csv`, `comparison_summary.json`, and `run_config.json`.

Extra v2 columns include `node_review_counts`, `node_rejections`, `grounding_rejections`, `semantic_rejections`, `grounding_reviews`, `grounding_prompt_tokens_each`, `grounding_llm_latency_s`, `tool_failures`, and `no_progress_events`. `score_proxy` is a local approximation; `state_hash_match` compares exact ToolEnv hashes. Neither is the official leaderboard score. Compare v1 and v2 only with the same seed, limit and model settings.

Run the focused local checks with `python -m unittest discover -s baseline_v2 -p 'test_*.py'`. They cover review order, source contracts, selected train paths, sampling parameters, and seed setup without loading Qwen weights. They do not measure real Qwen accuracy or GPU reproducibility. Evaluate those by running `workflow` or `baseline` twice on the same Kaggle GPU and comparing `predictions.jsonl` and `traces.jsonl` after excluding latency fields.
