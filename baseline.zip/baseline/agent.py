"""One-action-at-a-time LifeMate agent with schema repair and no-progress guard."""
from __future__ import annotations

import json
import time

from common import allowed_specs, compact_history, dumps


SYSTEM = """Bạn là agent LifeMate, xử lý lời nói tiếng Việt bằng các tool có sẵn.
Mỗi lượt chỉ xuất MỘT object JSON, không markdown hay giải thích:
{"type":"call","name":"app.tool","arguments":{...}}
{"type":"ask","tool_name":"app.tool","params":["required_field"]}
{"type":"done"}

Quy tắc:
- Chỉ gọi tool được liệt kê. Chỉ chọn một hành động mỗi lượt; bạn sẽ nhận kết quả tool rồi quyết định tiếp.
- Nếu đã hoàn thành, điều kiện không thỏa, ngoài phạm vi tool, hoặc không xác định được việc cần làm: done.
- Nếu biết tool đích nhưng thông tin bắt buộc thực sự thiếu: ask. Với ID/dữ liệu có thể tra cứu, hãy gọi tool read/search trước. Không đoán ID hoặc thông tin người dùng chưa cho.
- Các tool call trong history đã được áp dụng vào trạng thái ban đầu; không chạy lại.
- Khi tool response cho biết chưa xong, dùng nó để quyết định bước tiếp theo.
- Argument phải đúng schema, enum, format, required và x-one-of. Thời gian tương đối dựa vào current_time/timezone.
- Nếu có validation_feedback, sửa đề xuất theo thông tin đã biết hoặc chọn tool tra cứu. Nếu không có thông tin mới, dùng ask cho trường bắt buộc còn thiếu.
- Không đọc state.json; dữ liệu app chỉ có thể lấy qua tool.
"""


def parse_action(text):
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char != "{":
            continue
        try:
            obj, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and obj.get("type") in ("call", "ask", "done"):
            return obj
    return None


def missing_fields(spec, args):
    args = args if isinstance(args, dict) else {}
    params = spec.get("parameters") or {}
    empty = (None, "", [], {})
    missing = [key for key in params.get("required", []) if args.get(key) in empty]
    groups = params.get("x-one-of") or []
    if groups and not any(all(args.get(key) not in empty for key in group) for group in groups):
        missing.extend(groups[0])
    return sorted(set(missing))


def valid_ask(name, params, specs):
    if name not in specs or name == "sys.ask_missing_info":
        return False
    if not isinstance(params, list) or not params or not all(isinstance(p, str) for p in params):
        return False
    schema = specs[name].get("parameters") or {}
    required = set(schema.get("required", []))
    for group in schema.get("x-one-of") or []:
        required.update(group)
    return set(params) <= required


class Agent:
    def __init__(self, llm, catalog, ToolEnv, root, max_tool_calls=10,
                 max_decisions=24, max_repairs=3, max_prompt_tokens=14500,
                 max_new_tokens=384):
        self.llm = llm
        self.catalog = catalog
        self.ToolEnv = ToolEnv
        self.root = root
        self.max_tool_calls = max_tool_calls
        self.max_decisions = max_decisions
        self.max_repairs = max_repairs
        self.max_prompt_tokens = max_prompt_tokens
        self.max_new_tokens = max_new_tokens

    def messages(self, row, transcript, observations, feedback):
        context = {key: value for key, value in row["context"].items() if key != "installed_apps"}
        specs = allowed_specs(row, self.catalog)
        history = compact_history(row.get("history") or [])
        observed = observations[-8:].copy()
        trimmed = False
        while True:
            payload = {
                "request": transcript, "context": context,
                "history": history, "available_tools": specs,
                "executed_calls": [{"name": x["name"], "arguments": x["arguments"]} for x in observations],
                "tool_observations": observed,
                "validation_feedback": feedback,
            }
            messages = [{"role": "system", "content": SYSTEM},
                        {"role": "user", "content": dumps(payload)}]
            tokens = self.llm.count(messages)
            if tokens <= self.max_prompt_tokens:
                return messages, tokens, trimmed
            trimmed = True
            if history:
                history.pop(0)
            elif len(observed) > 1:
                observed.pop(0)
            elif observed and isinstance(observed[-1].get("result"), str) and len(observed[-1]["result"]) > 1500:
                observed[-1] = {**observed[-1], "result": observed[-1]["result"][:1500] + " [truncated]"}
            else:
                raise ValueError(f"Prompt needs {tokens} tokens after safe trimming; tool schemas cannot be dropped")

    def run(self, row, transcript):
        env = self.ToolEnv("train", row["id"], root=self.root)
        specs = {spec["name"]: spec for spec in allowed_specs(row, self.catalog)}
        observations = []
        trace = []
        feedback = None
        repair_streak = 0
        last_missing = None
        last_invalid = None
        parse_streak = 0
        duplicate_streak = 0
        prompt_tokens_each = []
        generated_total = 0
        llm_latency = 0.0
        repairs_total = 0
        invalid_total = 0
        parse_total = 0
        duplicates_total = 0
        any_trim = False
        stop_reason = "decision_limit"
        start = time.perf_counter()

        for decision_number in range(1, self.max_decisions + 1):
            if len(env.get_tool_calls()) >= self.max_tool_calls:
                stop_reason = "tool_limit"
                break
            try:
                messages, estimated_tokens, trimmed = self.messages(
                    row, transcript, observations, feedback)
            except ValueError as error:
                trace.append({"decision": decision_number, "event": "context_overflow", "error": str(error)})
                stop_reason = "context_overflow"
                break
            any_trim |= trimmed
            output = self.llm.complete(messages, max_new_tokens=self.max_new_tokens)
            prompt_tokens_each.append(output["prompt_tokens"])
            generated_total += output["generation_tokens"]
            llm_latency += output["latency_s"]
            event = {
                "decision": decision_number, "prompt_tokens": output["prompt_tokens"],
                "generation_tokens": output["generation_tokens"],
                "llm_latency_s": output["latency_s"], "context_trimmed": trimmed,
                "raw_output": output["text"],
            }
            action = parse_action(output["text"])
            event["action"] = action
            if action is None:
                parse_total += 1
                parse_streak += 1
                feedback = "Không parse được JSON. Chỉ xuất một object JSON đúng 1 trong 3 dạng: call, ask, done."
                event["error"] = feedback
                trace.append(event)
                if parse_streak >= self.max_repairs:
                    stop_reason = "parse_error"
                    break
                continue
            parse_streak = 0

            if action["type"] == "done":
                trace.append(event)
                stop_reason = "done"
                break

            if action["type"] == "ask":
                name, params = action.get("tool_name"), action.get("params")
                if not valid_ask(name, params, specs):
                    feedback = "ask không hợp lệ: tool_name phải là tool khả dụng và params phải là các trường required/x-one-of."
                    event["error"] = feedback
                    trace.append(event)
                    repair_streak += 1
                    repairs_total += 1
                    if repair_streak >= self.max_repairs:
                        stop_reason = "invalid_ask"
                        break
                    continue
                result = env.call("sys.ask_missing_info", {"tool_name": name, "params": params})
                event["tool_result"] = result
                trace.append(event)
                stop_reason = "ask_missing_info"
                break

            name, args = action.get("name"), action.get("arguments")
            if not isinstance(name, str) or not isinstance(args, dict):
                feedback = "call cần name là string và arguments là object JSON."
                event["error"] = feedback
                trace.append(event)
                repair_streak += 1
                repairs_total += 1
                if repair_streak >= self.max_repairs:
                    stop_reason = "invalid_call_json"
                    break
                continue
            if name not in specs:
                feedback = f"Tool {name!r} không khả dụng cho mẫu này. Chọn từ available_tools."
                event["error"] = feedback
                trace.append(event)
                repair_streak += 1
                repairs_total += 1
                if repair_streak >= self.max_repairs:
                    stop_reason = "unavailable_tool"
                    break
                continue

            call_key = (name, dumps(args))
            previous_keys = {(x["name"], dumps(x["arguments"])) for x in observations}
            if call_key in previous_keys:
                duplicate_streak += 1
                duplicates_total += 1
                feedback = "Call này đã được thực thi với cùng arguments. Đọc tool_observations và chọn bước khác hoặc done."
                event["error"] = feedback
                trace.append(event)
                if duplicate_streak >= 2:
                    stop_reason = "duplicate_no_progress"
                    break
                continue

            validation = env.validate(name, args)
            event["validation"] = validation
            if not validation["ok"]:
                invalid_total += 1
                repairs_total += 1
                repair_streak += 1
                missing = missing_fields(specs[name], args)
                event["missing_fields"] = missing
                missing_key = (name, tuple(missing), len(observations))
                invalid_key = (name, dumps(args), validation["error"], len(observations))
                no_new_info = bool(missing) and last_missing == missing_key
                repeated_invalid = not missing and last_invalid == invalid_key
                event["no_new_information"] = no_new_info or repeated_invalid
                if missing and (no_new_info or repair_streak >= self.max_repairs):
                    result = env.call("sys.ask_missing_info", {"tool_name": name, "params": missing})
                    event["tool_result"] = result
                    trace.append(event)
                    stop_reason = "ask_missing_info"
                    break
                if repeated_invalid or repair_streak >= self.max_repairs:
                    trace.append(event)
                    stop_reason = "validation_no_progress"
                    break
                last_missing = missing_key
                last_invalid = invalid_key
                feedback = {
                    "tool": name, "submitted_arguments": args,
                    "schema_error": validation["error"], "missing_fields": missing,
                    "missing_field_specs": {key: specs[name]["parameters"]["properties"].get(key, {})
                                            for key in missing},
                    "instruction": "Sửa bằng bằng chứng hiện có hoặc chọn tool tra cứu. Nếu không thể biết giá trị, dùng ask; không đoán.",
                }
                trace.append(event)
                continue

            result = env.call(name, args)
            event["tool_result"] = result
            trace.append(event)
            observations.append({
                "name": name, "arguments": args,
                "result": dumps(result)[:12000] + (" [truncated]" if len(dumps(result)) > 12000 else ""),
            })
            feedback = None
            repair_streak = 0
            duplicate_streak = 0
            last_missing = None
            last_invalid = None
            if name == "sys.ask_missing_info":
                stop_reason = "ask_missing_info"
                break
        else:
            stop_reason = "decision_limit"

        calls = env.get_tool_calls()
        return {
            "id": row["id"], "transcript": transcript,
            "tool_calls": calls, "state_hash": env.get_state_hash(),
            "stop_reason": stop_reason, "decisions": len(trace),
            "tool_iterations": len(calls), "repair_attempts": repairs_total,
            "invalid_schema_proposals": invalid_total, "parse_errors": parse_total,
            "duplicate_proposals": duplicates_total,
            "prompt_tokens_each": prompt_tokens_each,
            "prompt_tokens_total": sum(prompt_tokens_each),
            "prompt_tokens_max": max(prompt_tokens_each, default=0),
            "generation_tokens_total": generated_total,
            "llm_latency_s": llm_latency,
            "agent_latency_s": time.perf_counter() - start,
            "context_trimmed": any_trim,
            "trace": trace,
        }
