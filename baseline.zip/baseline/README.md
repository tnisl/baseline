# LifeMate baseline experiments

Models:
- ASR: vinai/PhoWhisper-medium
- Agent: Qwen/Qwen3-4B-Instruct-2507

Three experiments use the same deterministic sample IDs:
1. asr: audio to transcript, WER/CER against train.audio_text.
2. workflow: train.audio_text to the agent and zaic_tools.
3. baseline: PhoWhisper transcript to the same agent and zaic_tools.

The agent receives only the request transcript, context, history, installed tool schemas, and results of tool calls it has actually made. Gold labels are read only for evaluation after the agent finishes. Each experiment uses a fresh ToolEnv per sample. The gold state hash is computed in a separate evaluation session.

ASR decodes the provided 16 kHz PCM WAV files with Python's `wave` module and calls PhoWhisper's processor and `generate()` directly. This avoids the ASR pipeline's optional TorchCodec import, which can fail when Kaggle's TorchCodec and PyTorch builds differ.

## Kaggle setup

Upload the extracted train+public_test folder and this baseline folder as Kaggle inputs, or place them together under /kaggle/working. Enable a GPU and Internet for the first download of model weights. Open kaggle_runner.ipynb and run its cells. Set LIMIT=0 in that notebook to use all 1,545 train samples. Default is 50 samples so the first run is manageable. The notebook now uses vLLM for Qwen by default and ASR batch size 1 to reduce peak GPU memory.

Both models can be supplied as local directories using --asr-model and --llm-model if weights are predownloaded. Install requirements-vllm.txt in a fresh Kaggle session for vLLM; it provides a compatible CUDA/PyTorch stack. For the Transformers backend, install requirements.txt instead. The final competition container must carry the weights and run offline.

## CLI

Install dependencies in Kaggle:

    python -m pip install -r baseline/requirements-vllm.txt

Run all three experiments:

    python baseline/run.py --mode all --data-root train+public_test --limit 50 --output-dir /kaggle/working/lifemate_baseline --llm-backend vllm

Run each independently:

    python baseline/run.py --mode asr --data-root train+public_test --limit 50
    python baseline/run.py --mode workflow --data-root train+public_test --limit 50
    python baseline/run.py --mode baseline --data-root train+public_test --limit 50

For the full train split, use --limit 0. For baseline mode, the runner reuses matching ASR predictions under the output directory; if they are absent or incompatible, it computes them. All mode computes ASR first, releases that model from memory, then loads Qwen for the two agent experiments.

The default output directory on Kaggle is /kaggle/working/lifemate_baseline. The data root can be auto-discovered when --data-root is omitted.

## vLLM memory controls

Default vLLM settings are `--vllm-max-model-len 12288`, `--vllm-gpu-memory-utilization 0.82`, `--vllm-tensor-parallel-size 1`, `--vllm-attention-backend TRITON_ATTN`, `--vllm-dtype float16`, `--max-prompt-tokens 11500`, `--max-new-tokens 256`, and `--asr-batch-size 1`. Tesla T4 requires float16 because its compute capability 7.5 cannot run bfloat16 in vLLM. Triton attention avoids FlashInfer's runtime kernel link step, which can fail on Kaggle T4 with `/usr/bin/ld: cannot find -lcuda`. On A30 or another GPU where it works, `--vllm-attention-backend FLASH_ATTN` may be faster. Only one Qwen request runs at a time because tool results are needed between decisions. CUDA graphs are disabled by default to save VRAM; use `--vllm-use-cuda-graphs` if memory permits and it improves speed. On a two-GPU Kaggle runtime, `--vllm-tensor-parallel-size 2` can split model weights across GPUs. Lower `--vllm-max-model-len` and `--max-prompt-tokens` together if engine initialization still runs out of memory. A shorter context can cause `context_overflow` on tool-heavy cases, so inspect that stop reason in the report. vLLM manages a KV cache and can be faster, but does not guarantee lower memory use in every environment.

For the original Transformers comparison, use `--llm-backend transformers` and install `requirements.txt`. Keep the same sampled IDs, but compare latency and score separately because the backends can produce different outputs.

## Output files

- asr/predictions.jsonl: transcript and inference timing per sample.
- asr/cases.csv, errors.csv, summary.json, report.md, charts.png: WER, CER, edits, durations, latency and worst ASR cases.
- workflow_gold/ and baseline_asr/: predictions.jsonl (id, tool_calls, state_hash), traces.jsonl, cases.csv, errors.csv, summary.json, report.md, charts.png.
- comparison.csv and comparison_summary.json: per-sample difference between workflow with gold text and baseline with ASR text.
- run_config.json: arguments and selected IDs.

The agent summaries include actual Qwen input-token count per decision, total and maximum context tokens per sample, tool-call count, LLM decision count, repair count, stop reasons, schema errors and latency. Traces record each generated action, validation result and tool response.

## Interpretation

The local state_hash_match is exact because it uses zaic_tools. score_proxy approximates the contest tool-call score with name/argument matching and fuzzy token F1; its string normalization may differ from the private scorer. Use it to diagnose cases, not as an official leaderboard score. The comparison label asr_sensitive means gold-text workflow succeeded and ASR-text workflow failed; it does not prove transcription was the only cause because tool generation can vary.

ASR latency recorded for every item in a batch is the full batch wall time, because each item waits for the batch to finish. The limit of 10 tool calls and 3 argument repairs is a baseline guard. The default vLLM prompt limit is 11,500 tokens, with up to 256 generated tokens, below its configured 12,288-token context and the contest 16K limit. If a prompt exceeds the limit, old history and old observations are trimmed before any tool schemas; the trace records this. Baseline latency per sample estimates ASR batch wall time plus agent latency; it does not include time waiting for the batch to fill or other requests to finish.

Each run overwrites files for its mode. Keep identical seed, limit, models and output directory when comparing experiments.
